import { useState, useMemo, useRef, useEffect, useCallback } from "react";
import * as XLSX from "xlsx";
import {
  Calendar, Clock, Store, Bell, ChevronLeft, ChevronRight, Check,
  AlertTriangle, BarChart2, List, Plus, RefreshCw, ArrowLeftRight,
  Upload, Edit3, Save, X, Eye, EyeOff, Settings, LogOut,
  CheckCircle, Users, Trash2, Download, UserPlus, Key, Lock, Coffee,
  Target, TrendingUp, TrendingDown, Minus,
} from "lucide-react";

const FONT_CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Sora:wght@400;600;700;800&family=JetBrains+Mono:wght@400;600;700&display=swap');
  *{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
  body{font-family:'Sora',sans-serif}
  input[type=range]{accent-color:#F97316;width:100%}
  textarea{resize:none;outline:none}
  ::-webkit-scrollbar{width:2px}
  ::-webkit-scrollbar-thumb{background:#2D3A4A;border-radius:2px}
  @keyframes slideUp{from{transform:translateY(16px);opacity:0}to{transform:translateY(0);opacity:1}}
  @keyframes fadeIn{from{opacity:0}to{opacity:1}}
  @keyframes shake{0%,100%{transform:translateX(0)}20%,60%{transform:translateX(-6px)}40%,80%{transform:translateX(6px)}}
  .shake{animation:shake 0.4s ease}
`;

const C = {
  bg:'#0A0E14', card:'#141920', elevated:'#1C2331', border:'#1E2A3A',
  accent:'#F97316', accentMut:'rgba(249,115,22,0.12)', accentBrd:'rgba(249,115,22,0.35)',
  text:'#F0F6FC', muted:'#7D8FA1', dim:'#2D3A4A',
  green:'#3FB950', greenMut:'rgba(63,185,80,0.13)',
  yellow:'#E3A007', yellowMut:'rgba(227,160,7,0.13)',
  red:'#F85149', redMut:'rgba(248,81,73,0.13)',
  blue:'#58A6FF', blueMut:'rgba(88,166,255,0.13)',
  purple:'#BC8CFF', purpleMut:'rgba(188,140,255,0.13)',
};

const SHIFTS_DEFAULT = {
  A:{id:'A',name:'Turno A',start:'08:00',end:'14:00',hours:6,   breakMin:0,  netHours:6,  color:'#58A6FF',muted:'rgba(88,166,255,0.15)'},
  B:{id:'B',name:'Turno B',start:'08:00',end:'15:30',hours:7.5, breakMin:30, netHours:7,  color:'#3FB950',muted:'rgba(63,185,80,0.15)'},
  C:{id:'C',name:'Turno C',start:'09:00',end:'20:00',hours:11,  breakMin:60, netHours:10, color:'#E3A007',muted:'rgba(227,160,7,0.15)'},
};

const INIT_PINS = {
  1:'1234',2:'2345',3:'3456',4:'4567',5:'5678',
  6:'6789',7:'7890',8:'8901',9:'9012',10:'0123',
  11:'1111',12:'2222',13:'3333',14:'0000',
};

const INIT_EMPS = [
  {id:1, name:'Ana Garcia',         init:'AG', role:'employee'},
  {id:2, name:'Carlos Lopez',       init:'CL', role:'employee'},
  {id:3, name:'Maria Fernandez',    init:'MF', role:'employee'},
  {id:4, name:'Jose Martinez',      init:'JM', role:'employee'},
  {id:5, name:'Laura Sanchez',      init:'LS', role:'employee'},
  {id:6, name:'Pedro Ruiz',         init:'PR', role:'employee'},
  {id:7, name:'Elena Torres',       init:'ET', role:'employee'},
  {id:8, name:'Diego Moreno',       init:'DM', role:'employee'},
  {id:9, name:'Sofia Jimenez',      init:'SJ', role:'employee'},
  {id:10,name:'Miguel Romero',      init:'MR', role:'employee'},
  {id:11,name:'Carmen Diaz',        init:'CD', role:'employee'},
  {id:12,name:'Antonio Lopez',      init:'AL', role:'employee'},
  {id:13,name:'Isabel Vargas',      init:'IV', role:'employee'},
  {id:14,name:'Sara Coordinadora',  init:'SC', role:'coordinator'},
];

const EVENT_TYPES = [
  {id:'medico',     label:'Medico',      icon:'🏥', color:'#F85149', hasDuration:true},
  {id:'boda',       label:'Boda',        icon:'💍', color:'#BC8CFF', hasDuration:false},
  {id:'examen',     label:'Examen',      icon:'📝', color:'#E3A007', hasDuration:false},
  {id:'cita',       label:'Cita',        icon:'📅', color:'#58A6FF', hasDuration:false},
  {id:'viaje',      label:'Viaje',       icon:'✈️',  color:'#3FB950', hasDuration:false},
  {id:'cumpleanos', label:'Cumpleanos',  icon:'🎂', color:'#F97316', hasDuration:false},
  {id:'otro',       label:'Otro',        icon:'⭐', color:'#79C0FF', hasDuration:false},
];
const VISIBILITY_OPTS = [
  {id:'self',        icon:'🔒', label:'Solo yo',        desc:'Solo tu puedes verlo'},
  {id:'coordinator', icon:'👤', label:'Coordinador/a',  desc:'Tu y el coordinador'},
  {id:'all',         icon:'👥', label:'Todos',          desc:'Visible para el equipo'},
];
function isEventVisible(ev, userId, userRole){
  if(ev.ownerId===userId) return true;
  if(ev.visibility==='all') return true;
  if(ev.visibility==='coordinator'&&userRole==='coordinator') return true;
  return false;
}

const DAYS    = ['Lun','Mar','Mie','Jue','Vie','Sab','Dom'];
const DAYSL   = ['Lunes','Martes','Miercoles','Jueves','Viernes','Sabado','Domingo'];
const MONTHS  = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];
const MONTHS_CAP = ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'];
const MONTHS_S = ['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic'];

function buildMonthSched(weekSched, year, month) {
  const result = {};
  const dim = new Date(year, month + 1, 0).getDate();
  Object.entries(weekSched).forEach(([empId, weekArr]) => {
    result[empId] = {};
    for (let d = 1; d <= dim; d++) {
      const date = new Date(year, month, d);
      const dow = (date.getDay() + 6) % 7;
      const key = `${year}-${String(month+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
      result[empId][key] = weekArr[dow] || null;
    }
  });
  return result;
}

const NOW = new Date();
const CUR_YEAR = NOW.getFullYear();
const CUR_MONTH = NOW.getMonth();

function initMonthSched() {
  const INIT_SCHED = {
    1:['A','A','B',null,'C',null,null], 2:['B','B',null,'A','A','B',null],
    3:['C',null,'A','A','B',null,null], 4:['A','B','A',null,'C',null,null],
    5:[null,'A','A','B','A',null,null], 6:['B','C',null,'A','A',null,null],
    7:['A','A','C',null,'B',null,null], 8:[null,'B','A','A',null,'C',null],
    9:['A',null,'B','A','A',null,null], 10:['C','A',null,'B','A',null,null],
    11:['B','A','A',null,'C',null,null],12:['A','B',null,'A','B',null,null],
    13:[null,'A','C','A',null,'B',null],
  };
  return buildMonthSched(INIT_SCHED, CUR_YEAR, CUR_MONTH);
}

const INIT_MONTH_SCHED = initMonthSched();

const INIT_REQS = [
  {id:1,type:'swap',fromId:2,toId:5,fromDate:`${CUR_YEAR}-${String(CUR_MONTH+1).padStart(2,'0')}-06`,toDate:`${CUR_YEAR}-${String(CUR_MONTH+1).padStart(2,'0')}-06`,fromShift:'B',toShift:'A',status:'pending_employee',date:new Date().toISOString().slice(0,10),note:'Tengo cita medica'},
  {id:2,type:'market',fromId:7,dateStr:`${CUR_YEAR}-${String(CUR_MONTH+1).padStart(2,'0')}-12`,shift:'C',status:'available',date:new Date().toISOString().slice(0,10),note:'Ofrezco turno C'},
  {id:3,type:'compensation',fromId:3,dateStr:`${CUR_YEAR}-${String(CUR_MONTH+1).padStart(2,'0')}-15`,hours:-1.5,reason:'salir_antes',status:'pending_coordinator',date:new Date().toISOString().slice(0,10),note:'Necesito salir antes'},
  {id:4,type:'self_swap',fromId:4,fromDate:`${CUR_YEAR}-${String(CUR_MONTH+1).padStart(2,'0')}-07`,toDate:`${CUR_YEAR}-${String(CUR_MONTH+1).padStart(2,'0')}-14`,fromShift:'A',status:'pending_coordinator',date:new Date().toISOString().slice(0,10),note:'Cambio de semana'},
];

const INIT_HIST = [
  {id:101,type:'swap',desc:'Cambio aprobado',fromId:1,toId:6,date:new Date().toISOString().slice(0,10),status:'applied'},
  {id:102,type:'compensation',desc:'Compensacion aprobada',fromId:5,date:new Date().toISOString().slice(0,10),status:'applied'},
];

// --- UTILS --------------------------------------------------------------------
const AV_COLS=['#58A6FF','#3FB950','#E3A007','#F85149','#BC8CFF','#F78166','#79C0FF','#56D364','#FFA657','#FF7B72','#D2A8FF','#A5F3FC','#86EFAC'];
const avColor = s=>AV_COLS[((s||'??').charCodeAt(0)+(s||'??').charCodeAt(1))%AV_COLS.length];
const today=()=>{const d=new Date();d.setHours(0,0,0,0);return d;};
const todayStr=()=>today().toISOString().slice(0,10);
function autoInit(n){const p=n.trim().split(' ').filter(Boolean);return p.length>=2?(p[0][0]+p[1][0]).toUpperCase():(p[0]||'?').slice(0,2).toUpperCase();}
function parseHH(s){if(!s)return 0;const[h,m]=s.split(':').map(Number);return(h||0)+(m||0)/60;}
function calcHours(a,b){let d=parseHH(b)-parseHH(a);if(d<0)d+=24;return Math.round(d*10)/10;}
function breakLabel(min){if(!min||min===0)return'Sin descanso';if(min<60)return`${min}min descanso`;return`${min/60}h descanso`;}
function monthYearStr(y,m){const n=MONTHS_CAP[m];return`${n} ${y}`;}
function dateStrToLabel(ds){if(!ds)return'--';const d=new Date(ds+'T00:00:00');return`${DAYS[(d.getDay()+6)%7]} ${d.getDate()} ${MONTHS_S[d.getMonth()]}`;}
function daysInMonth(y,m){return new Date(y,m+1,0).getDate();}
function getDayKey(y,m,d){return`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`;}

function monthNetHours(empId, monthSched, shifts, y, m) {
  const emp = monthSched[empId] || {};
  const dim = daysInMonth(y, m);
  let total = 0;
  for (let d = 1; d <= dim; d++) {
    const key = getDayKey(y, m, d);
    const sid = emp[key];
    if (sid && shifts[sid]) total += shifts[sid].netHours;
  }
  return Math.round(total * 10) / 10;
}

function expectedMonthHours(y, m) {
  return Math.round((daysInMonth(y, m) / 7) * 40 * 10) / 10;
}

const STATUS_LABEL={pending_employee:'En espera tuya',pending_coordinator:'En coordinacion',rejected:'Rechazado',applied:'Aplicado',accepted_employee:'Acordado',available:'Publicado'};
const STATUS_VAR  ={pending_employee:'warn',pending_coordinator:'accent',rejected:'red',applied:'blue',accepted_employee:'green',available:'purple'};

// --- ATOMS --------------------------------------------------------------------
function Ava({init,size=36}){
  const c=avColor(init||'??');
  return <div style={{width:size,height:size,borderRadius:size/2,flexShrink:0,background:`${c}22`,border:`1.5px solid ${c}55`,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'Sora',fontWeight:700,fontSize:size*.33,color:c}}>{init||'?'}</div>;
}
function ShiftPill({sid,shifts,small}){
  if(!sid||!shifts[sid])return <span style={{color:C.dim,fontSize:small?10:12}}>--</span>;
  const s=shifts[sid];
  return <span style={{background:s.muted,color:s.color,borderRadius:6,padding:small?'2px 7px':'3px 10px',fontSize:small?10:12,fontWeight:700,fontFamily:'JetBrains Mono',letterSpacing:'0.02em'}}>{s.id} {s.start}-{s.end}</span>;
}
function Badge({children,variant='warn'}){
  const m={warn:{bg:C.yellowMut,c:C.yellow},green:{bg:C.greenMut,c:C.green},red:{bg:C.redMut,c:C.red},blue:{bg:C.blueMut,c:C.blue},purple:{bg:C.purpleMut,c:C.purple},accent:{bg:C.accentMut,c:C.accent}};
  const v=m[variant]||m.warn;
  return <span style={{background:v.bg,color:v.c,borderRadius:5,padding:'2px 7px',fontSize:10,fontWeight:700,letterSpacing:'0.05em',textTransform:'uppercase',flexShrink:0}}>{children}</span>;
}
function Card({children,style={},accent=false}){
  return <div style={{background:C.card,border:`1px solid ${accent?C.accentBrd:C.border}`,borderRadius:14,padding:14,...style}}>{children}</div>;
}
function Btn({children,onClick,secondary=false,small=false,disabled=false,danger=false,style={}}){
  return <button onClick={onClick} disabled={disabled} style={{background:disabled?C.dim:danger?C.redMut:secondary?C.elevated:C.accent,color:disabled?C.muted:danger?C.red:'#fff',border:secondary||danger?`1px solid ${danger?C.red+'44':C.border}`:'none',borderRadius:11,padding:small?'9px 16px':'12px 18px',fontFamily:'Sora',fontWeight:700,fontSize:small?12:14,cursor:disabled?'not-allowed':'pointer',width:'100%',...style}}>{children}</button>;
}
function SLabel({children,style={}}){
  return <p style={{fontSize:10,color:C.muted,fontWeight:700,letterSpacing:'0.08em',textTransform:'uppercase',marginBottom:9,...style}}>{children}</p>;
}

function GoalBanner({netH, expectedH, style={}}) {
  const diff = netH - expectedH;
  const pct = Math.min(100, Math.round((netH/expectedH)*100));
  const col = Math.abs(diff) < expectedH*0.05 ? C.green : Math.abs(diff) < expectedH*0.12 ? C.yellow : C.red;
  const Icon = diff > 2 ? TrendingUp : diff < -2 ? TrendingDown : Minus;
  return (
    <div style={{background:C.elevated,borderRadius:11,padding:'10px 13px',...style}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:7}}>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <Target size={13} color={C.accent}/>
          <span style={{fontSize:11,fontWeight:700,color:C.muted}}>Objetivo mensual</span>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:4}}>
          <Icon size={12} color={col}/>
          <span style={{fontFamily:'JetBrains Mono',fontSize:11,fontWeight:700,color:col}}>{diff>=0?'+':''}{diff.toFixed(1)}h</span>
        </div>
      </div>
      <div style={{height:5,background:C.dim,borderRadius:3}}>
        <div style={{height:5,borderRadius:3,background:col,width:`${pct}%`,transition:'width 0.4s'}}/>
      </div>
      <div style={{display:'flex',justifyContent:'space-between',marginTop:5}}>
        <span style={{fontSize:10,color:C.muted}}>{netH}h acumuladas</span>
        <span style={{fontSize:10,color:C.muted}}>Ref. {expectedH}h (~40h/sem)</span>
      </div>
      <p style={{fontSize:9,color:C.dim,marginTop:4}}>Informativo - no restrictivo</p>
    </div>
  );
}

function PinInput({onComplete}){
  const [d,setD]=useState(['','','','']);
  const refs=[useRef(),useRef(),useRef(),useRef()];
  const upd=(i,val)=>{if(!/^\d?$/.test(val))return;const n=[...d];n[i]=val;setD(n);if(val&&i<3)refs[i+1].current?.focus();if(n.every(x=>x))onComplete(n.join(''));};
  const bk=(i,e)=>{if(e.key==='Backspace'&&!d[i]&&i>0)refs[i-1].current?.focus();};
  return(
    <div style={{display:'flex',gap:10,justifyContent:'center',marginBottom:6}}>
      {d.map((v,i)=><input key={i} ref={refs[i]} type="password" inputMode="numeric" maxLength={1} value={v} onChange={e=>upd(i,e.target.value)} onKeyDown={e=>bk(i,e)} style={{width:50,height:58,textAlign:'center',fontSize:26,fontFamily:'JetBrains Mono',fontWeight:700,color:C.text,background:C.card,border:`2px solid ${v?C.accent:C.border}`,borderRadius:13,outline:'none',transition:'border 0.15s'}}/>)}
    </div>
  );
}

// --- LOGIN --------------------------------------------------------------------
function LoginScreen({emps,pins,onLogin}){
  const [sel,setSel]=useState(null);
  const [step,setStep]=useState('select');
  const [err,setErr]=useState('');
  const [sk,setSk]=useState(0);
  const now=new Date();
  const handlePin=pin=>{
    if(pins[sel.id]===pin){onLogin(sel);}
    else{setErr('PIN incorrecto');setSk(k=>k+1);setTimeout(()=>setErr(''),2200);}
  };
  const expH = expectedMonthHours(CUR_YEAR, CUR_MONTH);
  return(
    <div style={{padding:'0 18px 40px',overflowY:'auto',maxHeight:'100%'}}>
      <div style={{paddingTop:48,paddingBottom:24,textAlign:'center'}}>
        <div style={{width:56,height:56,borderRadius:17,margin:'0 auto 14px',background:C.accentMut,border:`1.5px solid ${C.accentBrd}`,display:'flex',alignItems:'center',justifyContent:'center'}}>
          <Calendar size={26} color={C.accent}/>
        </div>
        <h1 style={{fontSize:25,fontWeight:800,color:C.text,marginBottom:5}}>TurnoApp</h1>
        <p style={{color:C.accent,fontSize:13,fontWeight:700}}>{DAYSL[(now.getDay()+6)%7]}, {now.getDate()} de {MONTHS[now.getMonth()]} de {now.getFullYear()}</p>
        <div style={{marginTop:10,background:C.elevated,borderRadius:10,padding:'8px 14px',display:'inline-flex',alignItems:'center',gap:7}}>
          <Target size={13} color={C.accent}/>
          <span style={{fontSize:11,color:C.muted}}>Objetivo {MONTHS_CAP[CUR_MONTH]}: <b style={{color:C.text,fontFamily:'JetBrains Mono'}}>{expH}h</b> <span style={{color:C.dim,fontSize:10}}>(~40h/sem)</span></span>
        </div>
      </div>
      {step==='select'?(
        <>
          <SLabel>Selecciona tu usuario</SLabel>
          <div style={{display:'flex',flexDirection:'column',gap:6,marginBottom:18}}>
            {emps.map(emp=>(
              <button key={emp.id} onClick={()=>{setSel(emp);setStep('pin');setErr('');}} style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:11,padding:'10px 13px',display:'flex',alignItems:'center',gap:10,cursor:'pointer',width:'100%'}}>
                <Ava init={emp.init} size={33}/>
                <div style={{textAlign:'left',flex:1}}>
                  <div style={{fontSize:13,fontWeight:700,color:C.text}}>{emp.name}</div>
                  <div style={{fontSize:10,color:emp.role==='coordinator'?C.accent:C.muted,fontWeight:600}}>{emp.role==='coordinator'?'Coordinadora':'Empleado/a'}</div>
                </div>
                <ChevronRight size={14} color={C.muted}/>
              </button>
            ))}
          </div>
        </>
      ):(
        <div style={{animation:'slideUp 0.2s ease'}}>
          <button onClick={()=>{setStep('select');setErr('');}} style={{background:'none',border:'none',cursor:'pointer',display:'flex',alignItems:'center',gap:6,color:C.muted,fontSize:13,marginBottom:22}}>
            <ChevronLeft size={16}/> Cambiar usuario
          </button>
          <div style={{textAlign:'center',marginBottom:28}}>
            <Ava init={sel.init} size={58}/>
            <div style={{fontSize:16,fontWeight:700,color:C.text,marginTop:11}}>{sel.name}</div>
            <div style={{fontSize:11,color:sel.role==='coordinator'?C.accent:C.muted,marginTop:3,fontWeight:600}}>{sel.role==='coordinator'?'Coordinadora':'Empleado/a'}</div>
          </div>
          <SLabel>PIN de 4 digitos</SLabel>
          <div key={sk}><PinInput onComplete={handlePin}/></div>
          {err&&<p style={{textAlign:'center',color:C.red,fontSize:12,fontWeight:600,marginTop:10,animation:'fadeIn 0.15s ease'}}>{err}</p>}
          <p style={{textAlign:'center',color:C.dim,fontSize:11,marginTop:18}}>Coordinadora: 0000</p>
        </div>
      )}
    </div>
  );
}

// --- BOTTOM NAV ---------------------------------------------------------------
function BottomNav({tab,setTab,user,pendingCount}){
  const isCoord=user.role==='coordinator';
  const tabs=isCoord
    ?[{id:'calendar',icon:<Calendar size={19}/>,label:'Calendario'},{id:'requests',icon:<List size={19}/>,label:'Solicitudes',badge:pendingCount},{id:'schedule',icon:<Edit3 size={19}/>,label:'Cuadrante'},{id:'team',icon:<Users size={19}/>,label:'Equipo'},{id:'metrics',icon:<BarChart2 size={19}/>,label:'Metricas'}]
    :[{id:'calendar',icon:<Calendar size={19}/>,label:'Mi mes'},{id:'requests',icon:<List size={19}/>,label:'Cambios',badge:pendingCount},{id:'market',icon:<Store size={19}/>,label:'Mercado'},{id:'notifs',icon:<Bell size={19}/>,label:'Alertas'},{id:'profile',icon:<Settings size={19}/>,label:'Perfil'}];
  return(
    <div style={{display:'flex',background:C.card,borderTop:`1px solid ${C.border}`,paddingBottom:'env(safe-area-inset-bottom,6px)',flexShrink:0}}>
      {tabs.map(t=>(
        <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,display:'flex',flexDirection:'column',alignItems:'center',padding:'9px 0 7px',background:'none',border:'none',cursor:'pointer',color:tab===t.id?C.accent:C.muted,fontFamily:'Sora',fontSize:9,fontWeight:700,gap:3,position:'relative',transition:'color 0.15s'}}>
          {t.icon}{t.label}
          {t.badge>0&&<span style={{position:'absolute',top:6,right:'50%',transform:'translateX(10px)',background:C.red,color:'#fff',borderRadius:6,minWidth:14,height:14,fontSize:9,fontWeight:700,display:'flex',alignItems:'center',justifyContent:'center',padding:'0 3px'}}>{t.badge}</span>}
        </button>
      ))}
    </div>
  );
}

// --- MONTH CALENDAR VIEW ------------------------------------------------------
function MonthCalView({empId, monthSched, shifts, year, month, requests=[], compact=false, onDayClick=null, events=[], userId=null, userRole='employee'}){
  const dim = daysInMonth(year, month);
  const firstDow = (new Date(year, month, 1).getDay() + 6) % 7;
  const todayD = today();
  const empData = monthSched[empId] || {};

  const cells = [];
  for(let i=0;i<firstDow;i++) cells.push(null);
  for(let d=1;d<=dim;d++) cells.push(d);
  while(cells.length%7!==0) cells.push(null);

  const hasPend = (d) => {
    const key = getDayKey(year, month, d);
    return requests.some(r => (r.fromDate===key||r.toDate===key||r.dateStr===key) && r.status.includes('pending'));
  };

  const dayEvents = (d) => {
    const key = getDayKey(year, month, d);
    return events.filter(ev => ev.dateKey===key && isEventVisible(ev, userId, userRole));
  };

  return (
    <div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:2,marginBottom:3}}>
        {DAYS.map(d=><div key={d} style={{textAlign:'center',fontSize:9,color:C.muted,fontWeight:700,padding:'2px 0'}}>{d}</div>)}
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:compact?1:2}}>
        {cells.map((day,i)=>{
          if(!day) return <div key={i}/>;
          const key = getDayKey(year, month, day);
          const sid = empData[key];
          const sh = sid && shifts[sid];
          const date = new Date(year, month, day);
          const isToday = date.toDateString()===todayD.toDateString();
          const dow = (date.getDay()+6)%7;
          const isWeekend = dow>=5;
          const pend = hasPend(day);
          const evs = dayEvents(day);
          return (
            <button key={i} onClick={()=>onDayClick&&onDayClick(day,key,sid)} style={{
              aspectRatio:'1', borderRadius:compact?4:7,
              border:`1.5px solid ${isToday?C.accent:sh?sh.color+'44':C.border}`,
              background:isToday?C.accentMut:sh?sh.muted:isWeekend?C.elevated+'80':'transparent',
              cursor:onDayClick?'pointer':'default',
              position:'relative', display:'flex', flexDirection:'column',
              alignItems:'center', justifyContent:'center', gap:0, outline:'none',
            }}>
              <span style={{fontSize:compact?8:10,fontWeight:isToday?800:500,color:isToday?C.accent:isWeekend&&!sh?C.dim:C.text}}>{day}</span>
              {sh&&<span style={{fontSize:compact?6:7,fontWeight:700,color:sh.color,fontFamily:'JetBrains Mono',lineHeight:1}}>{sh.id}</span>}
              {pend&&<div style={{position:'absolute',top:1,right:1,width:4,height:4,borderRadius:2,background:C.yellow}}/>}
              {evs.length>0&&!compact&&(
                <div style={{display:'flex',gap:1,marginTop:1,flexWrap:'wrap',justifyContent:'center'}}>
                  {evs.slice(0,3).map((ev,ei)=>{
                    const et=EVENT_TYPES.find(t=>t.id===ev.type);
                    return <div key={ei} style={{width:4,height:4,borderRadius:2,background:et?et.color:'#79C0FF',flexShrink:0}}/>;
                  })}
                </div>
              )}
              {evs.length>0&&compact&&<div style={{position:'absolute',bottom:1,left:'50%',transform:'translateX(-50%)',width:3,height:3,borderRadius:'50%',background:'#BC8CFF'}}/>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// --- CALENDAR SCREEN ----------------------------------------------------------
function CalendarScreen({user, emps, monthSched, shifts, requests, events=[], onAddEvent=()=>{}, onDeleteEvent=()=>{}}){
  const isCoord = user.role==='coordinator';
  const [viewYear, setViewYear] = useState(CUR_YEAR);
  const [viewMonth, setViewMonth] = useState(CUR_MONTH);
  const [mode, setMode] = useState('mine');
  const [selectedDay, setSelectedDay] = useState(null);
  const [viewEmpId, setViewEmpId] = useState(user.id);
  const [showEventModal, setShowEventModal] = useState(false);

  const dim = daysInMonth(viewYear, viewMonth);
  const netH = monthNetHours(viewEmpId, monthSched, shifts, viewYear, viewMonth);
  const expH = expectedMonthHours(viewYear, viewMonth);
  const diff = Math.round((netH - expH)*10)/10;
  const diffCol = Math.abs(diff) < expH*0.05 ? C.green : Math.abs(diff) < expH*0.12 ? C.yellow : C.red;

  const viewEmp = emps.find(e=>e.id===viewEmpId)||user;
  const empData = (monthSched[viewEmpId]||{});

  const selKey = selectedDay ? getDayKey(viewYear, viewMonth, selectedDay) : null;
  const selSid = selKey ? empData[selKey] : null;
  const selSh = selSid && shifts[selSid];

  const navigate = (dir) => {
    let m = viewMonth + dir, y = viewYear;
    if(m < 0){m=11;y--;}
    if(m > 11){m=0;y++;}
    setViewMonth(m); setViewYear(y); setSelectedDay(null);
  };

  const weeks = useMemo(()=>{
    const ws=[];
    for(let d=1;d<=dim;d++){
      const key=getDayKey(viewYear,viewMonth,d);
      const dow=(new Date(viewYear,viewMonth,d).getDay()+6)%7;
      if(dow===0||d===1){const wk=[];for(let dd=d;dd<d+7&&dd<=dim;dd++){const k=getDayKey(viewYear,viewMonth,dd);wk.push({d:dd,key:k,sid:empData[k]||null});}ws.push(wk);}
    }
    return ws;
  },[viewYear,viewMonth,dim,empData]);

  const weeklyHours = useMemo(()=>weeks.map(wk=>wk.reduce((s,{sid})=>s+(sid&&shifts[sid]?shifts[sid].netHours:0),0)),[weeks,shifts]);

  return (
    <div style={{padding:'0 15px'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:10}}>
        <button onClick={()=>navigate(-1)} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,width:34,height:34,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',color:C.muted}}><ChevronLeft size={17}/></button>
        <div style={{textAlign:'center'}}>
          <div style={{fontSize:19,fontWeight:800,color:C.text}}>{MONTHS_CAP[viewMonth]}</div>
          <div style={{fontSize:11,color:C.muted}}>{viewYear}</div>
        </div>
        <button onClick={()=>navigate(1)} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,width:34,height:34,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',color:C.muted}}><ChevronRight size={17}/></button>
      </div>

      <div style={{display:'flex',gap:6,marginBottom:11}}>
        {(isCoord?[['mine','Mi mes'],['team','Equipo']]:[ ['mine','Mi mes'],['weeks','Por semanas']]).map(([v,l])=>(
          <button key={v} onClick={()=>setMode(v)} style={{flex:1,padding:'7px',borderRadius:9,cursor:'pointer',background:mode===v?C.accentMut:C.card,border:`1px solid ${mode===v?C.accentBrd:C.border}`,color:mode===v?C.accent:C.muted,fontFamily:'Sora',fontSize:11,fontWeight:700}}>{l}</button>
        ))}
      </div>

      {isCoord&&mode!=='team'&&(
        <div style={{display:'flex',gap:5,overflowX:'auto',paddingBottom:6,marginBottom:8}}>
          {emps.filter(e=>e.role==='employee').map(e=>(
            <button key={e.id} onClick={()=>{setViewEmpId(e.id);setSelectedDay(null);}} style={{flexShrink:0,background:viewEmpId===e.id?C.accentMut:C.card,border:`1px solid ${viewEmpId===e.id?C.accentBrd:C.border}`,borderRadius:8,padding:'5px 9px',cursor:'pointer',display:'flex',alignItems:'center',gap:5}}>
              <Ava init={e.init} size={18}/>
              <span style={{fontSize:10,fontWeight:700,color:viewEmpId===e.id?C.accent:C.muted,whiteSpace:'nowrap'}}>{e.name.split(' ')[0]}</span>
            </button>
          ))}
        </div>
      )}

      {mode!=='team'&&(
        <Card style={{marginBottom:11,background:'linear-gradient(135deg,#141920,#18243A)'}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:8}}>
            <div>
              <p style={{fontSize:11,color:C.muted,marginBottom:3}}>{viewEmp.name} - {MONTHS_CAP[viewMonth]} {viewYear}</p>
              <div style={{fontFamily:'JetBrains Mono',fontSize:26,fontWeight:700,color:C.text,lineHeight:1}}>{netH}<span style={{fontSize:12,color:C.muted,marginLeft:2}}>h netas</span></div>
              <div style={{display:'flex',alignItems:'center',gap:6,marginTop:5}}>
                <div style={{width:7,height:7,borderRadius:4,background:diffCol}}/>
                <span style={{fontFamily:'JetBrains Mono',fontSize:11,fontWeight:600,color:diffCol}}>{diff>=0?'+':''}{diff}h vs obj. {expH}h</span>
              </div>
            </div>
            <div style={{display:'flex',gap:12}}>
              <div style={{textAlign:'center'}}>
                <div style={{fontFamily:'JetBrains Mono',fontSize:18,fontWeight:700,color:C.blue}}>{Object.values(empData).filter(Boolean).length}</div>
                <div style={{fontSize:9,color:C.muted}}>Turnos</div>
              </div>
              <div style={{textAlign:'center'}}>
                <div style={{fontFamily:'JetBrains Mono',fontSize:18,fontWeight:700,color:C.purple}}>{dim-Object.values(empData).filter(Boolean).length}</div>
                <div style={{fontSize:9,color:C.muted}}>Libres</div>
              </div>
            </div>
          </div>
          <div style={{height:4,background:C.dim,borderRadius:2}}>
            <div style={{height:4,borderRadius:2,background:diffCol,width:`${Math.min(100,Math.round((netH/expH)*100))}%`,transition:'width 0.4s'}}/>
          </div>
          <p style={{fontSize:9,color:C.dim,marginTop:4}}>Objetivo ~40h/semana - informativo</p>
        </Card>
      )}

      {mode==='mine'&&(
        <>
          <MonthCalView empId={viewEmpId} monthSched={monthSched} shifts={shifts} year={viewYear} month={viewMonth} requests={requests} onDayClick={(d,k,sid)=>setSelectedDay(selectedDay===d?null:d)} events={events} userId={user.id} userRole={user.role}/>
          <div style={{display:'flex',gap:8,marginTop:9,flexWrap:'wrap',alignItems:'center'}}>
            {Object.values(shifts).map(s=><div key={s.id} style={{display:'flex',alignItems:'center',gap:4}}><div style={{width:9,height:9,borderRadius:2,background:s.color}}/><span style={{fontSize:9,color:C.muted}}>{s.id} {s.netHours}h</span></div>)}
            <div style={{display:'flex',alignItems:'center',gap:4}}><div style={{width:9,height:9,borderRadius:2,background:'#BC8CFF'}}/><span style={{fontSize:9,color:C.muted}}>Aviso</span></div>
          </div>
          {selectedDay&&(()=>{
            const selKeyEvs = events.filter(ev=>ev.dateKey===selKey&&isEventVisible(ev,user.id,user.role));
            return(
            <Card accent style={{marginTop:10,animation:'slideUp 0.18s ease'}}>
              <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
                <div>
                  <div style={{fontSize:14,fontWeight:800,color:C.text}}>{DAYS[(new Date(viewYear,viewMonth,selectedDay).getDay()+6)%7]} {selectedDay} de {MONTHS_CAP[viewMonth]}</div>
                  <div style={{fontSize:10,color:C.muted}}>{viewYear}</div>
                </div>
                <div style={{display:'flex',gap:6,alignItems:'center'}}>
                  <button onClick={()=>setShowEventModal(true)} style={{background:C.purpleMut,border:`1px solid ${C.purple}44`,borderRadius:8,padding:'5px 9px',cursor:'pointer',display:'flex',alignItems:'center',gap:4}}>
                    <Plus size={12} color={C.purple}/><span style={{fontSize:10,fontWeight:700,color:C.purple}}>Aviso</span>
                  </button>
                  <button onClick={()=>setSelectedDay(null)} style={{background:'none',border:'none',cursor:'pointer',color:C.muted}}><X size={14}/></button>
                </div>
              </div>
              {selSh?(
                <><ShiftPill sid={selSid} shifts={shifts}/>
                <div style={{display:'flex',gap:14,marginTop:9}}>
                  {[{v:selSh.netHours+'h',l:'netas',col:C.green},{v:selSh.start,l:'entrada',col:C.blue},{v:selSh.end,l:'salida',col:C.purple}].map(m=>(
                    <div key={m.l} style={{textAlign:'center'}}><div style={{fontFamily:'JetBrains Mono',fontSize:14,fontWeight:700,color:m.col}}>{m.v}</div><div style={{fontSize:9,color:C.muted}}>{m.l}</div></div>
                  ))}
                </div>
                {selSh.breakMin>0&&<div style={{fontSize:10,color:C.muted,marginTop:5,display:'flex',alignItems:'center',gap:4}}><Coffee size={10} color={C.muted}/>{breakLabel(selSh.breakMin)}</div>}</>
              ):<p style={{fontSize:13,color:C.dim,fontWeight:600}}>Dia libre</p>}
              {selKeyEvs.length>0&&(
                <div style={{marginTop:11,borderTop:`1px solid ${C.border}`,paddingTop:10}}>
                  <p style={{fontSize:10,fontWeight:700,color:C.muted,marginBottom:7,textTransform:'uppercase',letterSpacing:'0.06em'}}>Avisos del dia</p>
                  {selKeyEvs.map(ev=>{
                    const et=EVENT_TYPES.find(t=>t.id===ev.type)||EVENT_TYPES[6];
                    const vis=VISIBILITY_OPTS.find(v=>v.id===ev.visibility)||VISIBILITY_OPTS[0];
                    const isOwner=ev.ownerId===user.id;
                    const owner=emps.find(e=>e.id===ev.ownerId);
                    return(
                      <div key={ev.id} style={{display:'flex',gap:9,alignItems:'flex-start',marginBottom:7,background:C.elevated,borderRadius:9,padding:'8px 10px',border:`1px solid ${et.color}33`}}>
                        <span style={{fontSize:16,lineHeight:1,flexShrink:0}}>{et.icon}</span>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap'}}>
                            <span style={{fontSize:12,fontWeight:700,color:C.text}}>{ev.title||et.label}</span>
                            <span style={{fontSize:9,color:et.color,fontWeight:700,background:`${et.color}20`,borderRadius:4,padding:'1px 6px'}}>{et.label}</span>
                          </div>
                          <div style={{display:'flex',gap:8,marginTop:3,flexWrap:'wrap',alignItems:'center'}}>
                            {ev.duration>0&&<span style={{fontSize:10,color:C.muted,display:'flex',alignItems:'center',gap:3}}><Clock size={9} color={C.muted}/>{ev.duration} min aprox.</span>}
                            <span style={{fontSize:9,color:C.dim}}>{vis.icon} {vis.label}</span>
                            {!isOwner&&owner&&<span style={{fontSize:9,color:C.muted}}>({owner.name.split(' ')[0]})</span>}
                          </div>
                          {ev.note&&<p style={{fontSize:10,color:C.muted,marginTop:3,fontStyle:'italic'}}>"{ev.note}"</p>}
                        </div>
                        {isOwner&&<button onClick={()=>onDeleteEvent(ev.id)} style={{background:'none',border:'none',cursor:'pointer',color:C.red,padding:2,flexShrink:0}}><Trash2 size={12}/></button>}
                      </div>
                    );
                  })}
                </div>
              )}
            </Card>
            );
          })()}
        </>
      )}
      {showEventModal&&(
        <EventModal
          user={user} emps={emps}
          defaultDate={selKey}
          onClose={()=>setShowEventModal(false)}
          onSubmit={ev=>{onAddEvent(ev);setShowEventModal(false);}}
        />
      )}

      {mode==='weeks'&&(
        <div>
          {weeks.map((wk,wi)=>{
            const wh=weeklyHours[wi];const wd=Math.round((wh-40)*10)/10;
            const col=Math.abs(wd)<2?C.green:Math.abs(wd)<5?C.yellow:C.red;
            return(
              <Card key={wi} style={{marginBottom:9}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
                  <span style={{fontSize:11,color:C.muted,fontWeight:700}}>Semana {wi+1}</span>
                  <div style={{display:'flex',gap:8,alignItems:'center'}}>
                    <span style={{fontSize:10,color:col,fontFamily:'JetBrains Mono'}}>{wd>=0?'+':''}{wd}h</span>
                    <span style={{fontFamily:'JetBrains Mono',fontSize:13,fontWeight:700,color:C.text}}>{wh}h</span>
                  </div>
                </div>
                <div style={{display:'flex',gap:4}}>
                  {wk.map(({d,key,sid})=>{
                    const sh=sid&&shifts[sid];
                    const isToday=new Date(viewYear,viewMonth,d).toDateString()===today().toDateString();
                    return(
                      <div key={d} style={{flex:1,textAlign:'center'}}>
                        <div style={{fontSize:8,color:isToday?C.accent:C.muted,fontWeight:isToday?700:400}}>{DAYS[(new Date(viewYear,viewMonth,d).getDay()+6)%7]}</div>
                        <div style={{height:32,borderRadius:5,background:sh?sh.muted:C.elevated,border:`1px solid ${sh?sh.color+'44':C.border}`,display:'flex',alignItems:'center',justifyContent:'center',margin:'3px 0'}}>
                          {sh?<span style={{fontSize:8,fontWeight:800,color:sh.color,fontFamily:'JetBrains Mono'}}>{sh.id}</span>:<span style={{fontSize:8,color:C.dim}}>--</span>}
                        </div>
                        <div style={{fontSize:8,color:C.muted}}>{d}</div>
                      </div>
                    );
                  })}
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {mode==='team'&&isCoord&&(
        <div>
          {emps.filter(e=>e.role==='employee').map(emp=>{
            const h=monthNetHours(emp.id,monthSched,shifts,viewYear,viewMonth);
            const exp=expectedMonthHours(viewYear,viewMonth);
            const d=Math.round((h-exp)*10)/10;
            const col=Math.abs(d)<exp*0.05?C.green:Math.abs(d)<exp*0.12?C.yellow:C.red;
            return(
              <div key={emp.id} style={{marginBottom:6}}>
                <div style={{display:'flex',alignItems:'center',gap:5,marginBottom:3}}>
                  <Ava init={emp.init} size={18}/>
                  <span style={{fontSize:10,color:C.muted,flex:1}}>{emp.name.split(' ')[0]}</span>
                  <span style={{fontFamily:'JetBrains Mono',fontSize:10,color:col,fontWeight:700}}>{h}h</span>
                  <span style={{fontFamily:'JetBrains Mono',fontSize:9,color:col}}>{d>=0?'+':''}{d}</span>
                </div>
                <MonthCalView empId={emp.id} monthSched={monthSched} shifts={shifts} year={viewYear} month={viewMonth} compact={true}/>
                <div style={{height:1,background:C.border,margin:'8px 0'}}/>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// --- SELF SWAP PICKER ---------------------------------------------------------
function SelfSwapPicker({monthSched,empId,shifts,fromKey,toKey,onFromPick,onToPick}){
  const [phase,setPhase]=useState('from');
  const [fy,setFY]=useState(CUR_YEAR);
  const [fm,setFM]=useState(CUR_MONTH);
  const [ty,setTY]=useState(CUR_YEAR);
  const [tm,setTM]=useState(CUR_MONTH);
  const empData=monthSched[empId]||{};
  const navF=(d)=>{let m=fm+d,y=fy;if(m<0){m=11;y--;}if(m>11){m=0;y++;}setFM(m);setFY(y);};
  const navT=(d)=>{let m=tm+d,y=ty;if(m<0){m=11;y--;}if(m>11){m=0;y++;}setTM(m);setTY(y);};
  const fromSh=fromKey?shifts[empData[fromKey]]||null:null;
  const toSh=toKey?shifts[empData[toKey]]||null:null;

  const handleFromPick=(key,sid)=>{
    onFromPick(key,sid);
    onToPick(null,null);
    setPhase('to');
  };

  const FullCal=({y,m,selected,onNav,filterFn,onPick,accentColor})=>{
    const dim=daysInMonth(y,m);
    const firstDow=(new Date(y,m,1).getDay()+6)%7;
    return(
      <div>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:10}}>
          <button onClick={()=>onNav(-1)} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,width:34,height:34,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',color:C.muted}}><ChevronLeft size={16}/></button>
          <div style={{textAlign:'center'}}>
            <div style={{fontSize:17,fontWeight:800,color:C.text}}>{MONTHS_CAP[m]}</div>
            <div style={{fontSize:11,color:C.muted}}>{y}</div>
          </div>
          <button onClick={()=>onNav(1)} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,width:34,height:34,cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',color:C.muted}}><ChevronRight size={16}/></button>
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:2,marginBottom:3}}>
          {DAYS.map(d=><div key={d} style={{textAlign:'center',fontSize:9,color:C.muted,fontWeight:700}}>{d}</div>)}
        </div>
        <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:3}}>
          {Array.from({length:firstDow},(_,i)=><div key={`e${i}`}/>)}
          {Array.from({length:dim},(_,i)=>{
            const d=i+1;
            const key=getDayKey(y,m,d);
            const sid=empData[key]||null;
            const sh=sid&&shifts[sid];
            const dow=(new Date(y,m,d).getDay()+6)%7;
            const isWeekend=dow>=5;
            const isToday=new Date(y,m,d).toDateString()===today().toDateString();
            const ok=filterFn(key,sid,isWeekend);
            const isSel=selected===key;
            return(
              <button key={d} onClick={()=>ok&&onPick(key,y,m,d,sid)} disabled={!ok} style={{
                aspectRatio:'1',borderRadius:8,outline:'none',
                cursor:ok?'pointer':'default',
                border:`1.5px solid ${isSel?accentColor:isToday?C.accentBrd:sh?sh.color+'44':C.border}`,
                background:isSel?`${accentColor}22`:sh?sh.muted:isWeekend?C.elevated+'90':'transparent',
                opacity:ok?1:0.2,
                display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:1,
              }}>
                <span style={{fontSize:11,fontWeight:isSel||isToday?800:500,color:isSel?accentColor:isToday?C.accent:C.text,lineHeight:1.1}}>{d}</span>
                {sh&&<span style={{fontSize:7,color:sh.color,fontFamily:'JetBrains Mono',fontWeight:700,lineHeight:1}}>{sh.id}</span>}
              </button>
            );
          })}
        </div>
      </div>
    );
  };

  const Legend=()=>(
    <div style={{display:'flex',gap:8,marginTop:8,flexWrap:'wrap'}}>
      {Object.values(shifts).map(s=>(
        <div key={s.id} style={{display:'flex',alignItems:'center',gap:3}}>
          <div style={{width:8,height:8,borderRadius:2,background:s.color}}/>
          <span style={{fontSize:9,color:C.muted,fontFamily:'JetBrains Mono'}}>{s.id} {s.netHours}h</span>
        </div>
      ))}
      <div style={{display:'flex',alignItems:'center',gap:3}}>
        <div style={{width:8,height:8,borderRadius:2,background:C.elevated,border:`1px solid ${C.border}`}}/>
        <span style={{fontSize:9,color:C.dim}}>Fin de semana</span>
      </div>
    </div>
  );

  const SummaryBar=()=>(
    <div style={{display:'flex',gap:6,marginBottom:12}}>
      <button
        onClick={()=>setPhase('from')}
        style={{
          flex:1,padding:'9px 8px',borderRadius:10,textAlign:'center',cursor:'pointer',
          background:phase==='from'?C.accentMut:fromKey?C.elevated:C.card,
          border:`1.5px solid ${phase==='from'?C.accent:fromKey?C.accentBrd+'80':C.border}`,
        }}
      >
        <div style={{fontSize:9,color:phase==='from'?C.accent:C.muted,fontWeight:700,marginBottom:2}}>1. Turno a mover</div>
        {fromKey
          ?<div style={{fontSize:11,fontWeight:700,color:C.text,lineHeight:1.3}}>
            {dateStrToLabel(fromKey)}
            {fromSh&&<span style={{display:'block',color:fromSh.color,fontFamily:'JetBrains Mono',fontSize:10}}>{fromSh.id} {fromSh.netHours}h</span>}
           </div>
          :<div style={{fontSize:10,color:C.muted}}>Pulsa un dia</div>}
      </button>
      <div style={{display:'flex',alignItems:'center',flexShrink:0}}>
        <RefreshCw size={15} color={fromKey?C.accent:C.dim}/>
      </div>
      <button
        onClick={()=>fromKey&&setPhase('to')}
        style={{
          flex:1,padding:'9px 8px',borderRadius:10,textAlign:'center',cursor:fromKey?'pointer':'default',
          background:phase==='to'?`${C.purple}22`:toKey?C.elevated:C.card,
          border:`1.5px solid ${phase==='to'?C.purple:toKey?C.purple+'60':C.border}`,
          opacity:fromKey?1:0.45,
        }}
      >
        <div style={{fontSize:9,color:phase==='to'?C.purple:C.muted,fontWeight:700,marginBottom:2}}>2. Nuevo dia</div>
        {toKey
          ?<div style={{fontSize:11,fontWeight:700,color:C.text,lineHeight:1.3}}>
            {dateStrToLabel(toKey)}
            {toSh&&<span style={{display:'block',color:toSh.color,fontFamily:'JetBrains Mono',fontSize:10}}>{toSh.id} {toSh.netHours}h</span>}
            {!toSh&&<span style={{display:'block',color:C.green,fontSize:10}}>Dia libre</span>}
           </div>
          :<div style={{fontSize:10,color:C.muted}}>{fromKey?'Ahora elige':'Primero elige origen'}</div>}
      </button>
    </div>
  );

  return(
    <div>
      <SummaryBar/>

      {phase==='from'&&(
        <div style={{animation:'slideUp 0.18s ease'}}>
          <div style={{background:C.accentMut,border:`1px solid ${C.accentBrd}`,borderRadius:9,padding:'7px 11px',marginBottom:10}}>
            <p style={{fontSize:11,fontWeight:700,color:C.accent}}>Paso 1 -- Elige el dia que quieres mover</p>
            <p style={{fontSize:10,color:C.muted,marginTop:2}}>Solo dias con turno asignado. Solo laborables (lun-vie).</p>
          </div>
          <FullCal
            y={fy} m={fm} selected={fromKey} onNav={navF}
            accentColor={C.accent}
            filterFn={(key,sid,isWeekend)=>!!sid&&!isWeekend}
            onPick={(key,y,m,d,sid)=>handleFromPick(key,sid)}
          />
          <Legend/>
        </div>
      )}

      {phase==='to'&&(
        <div style={{animation:'slideUp 0.18s ease'}}>
          <div style={{background:`${C.purple}18`,border:`1px solid ${C.purple}44`,borderRadius:9,padding:'7px 11px',marginBottom:10}}>
            <p style={{fontSize:11,fontWeight:700,color:C.purple}}>Paso 2 -- Elige el nuevo dia de destino</p>
            <p style={{fontSize:10,color:C.muted,marginTop:2}}>Puede ser cualquier dia laborable del mes, libre o con turno.</p>
          </div>
          <FullCal
            y={ty} m={tm} selected={toKey} onNav={navT}
            accentColor={C.purple}
            filterFn={(key,sid,isWeekend)=>key!==fromKey&&!isWeekend}
            onPick={(key,y,m,d,sid)=>onToPick(key,sid)}
          />
          <Legend/>
          {toKey&&(()=>{
            const fH=fromSh?fromSh.netHours:0;
            const tH=toSh?toSh.netHours:0;
            const netChange=Math.round((tH-fH)*10)/10;
            const diffWeeks=Math.floor(Math.abs(new Date(toKey+'T00:00:00')-new Date(fromKey+'T00:00:00'))/(7*86400000));
            return(
              <div style={{marginTop:10,background:C.elevated,borderRadius:9,padding:'10px 12px'}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:5}}>
                  <span style={{fontSize:11,fontWeight:700,color:C.text}}>Impacto horario</span>
                  <span style={{fontFamily:'JetBrains Mono',fontSize:12,fontWeight:700,color:netChange>0?C.green:netChange<0?C.yellow:C.green}}>
                    {netChange===0?'Sin cambio':(netChange>0?'+':'')+netChange+'h'}
                  </span>
                </div>
                <div style={{fontSize:10,color:C.muted,lineHeight:1.8}}>
                  <span>Mueves: </span><b style={{color:fromSh?fromSh.color:C.muted}}>{fromSh?fromSh.id+' ('+fromSh.netHours+'h)':'dia libre'}</b>
                  <span> del {dateStrToLabel(fromKey)}</span><br/>
                  <span>Al dia: </span><b style={{color:toSh?toSh.color:C.green}}>{toSh?toSh.id+' ('+toSh.netHours+'h)':'libre (el turno se traslada aqui)'}</b>
                  <span> {dateStrToLabel(toKey)}</span>
                </div>
                {diffWeeks>=1&&<p style={{fontSize:10,color:C.accent,marginTop:5}}>Cambio entre semanas distintas -- el computo 40h/sem se reequilibra en el mes.</p>}
                <p style={{fontSize:9,color:C.dim,marginTop:4}}>Informativo -- el coordinador revisara el impacto antes de aprobar.</p>
              </div>
            );
          })()}
        </div>
      )}
    </div>
  );
}

// --- MONTH DAY PICKER ---------------------------------------------------------
function MonthDayPicker({monthSched,empId,shifts,year,month,onPick,selected,filter='any',label}){
  const [y,setY]=useState(year);
  const [m,setM]=useState(month);
  const dim=daysInMonth(y,m);
  const empData=monthSched[empId]||{};
  const nav=(dir)=>{let nm=m+dir,ny=y;if(nm<0){nm=11;ny--;}if(nm>11){nm=0;ny++;}setM(nm);setY(ny);};
  return(
    <div>
      {label&&<SLabel>{label}</SLabel>}
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:8}}>
        <button onClick={()=>nav(-1)} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:7,padding:'4px 8px',cursor:'pointer',color:C.muted}}><ChevronLeft size={14}/></button>
        <span style={{fontSize:12,fontWeight:700,color:C.text}}>{MONTHS_CAP[m]} {y}</span>
        <button onClick={()=>nav(1)} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:7,padding:'4px 8px',cursor:'pointer',color:C.muted}}><ChevronRight size={14}/></button>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:2,marginBottom:3}}>
        {DAYS.map(d=><div key={d} style={{textAlign:'center',fontSize:8,color:C.muted,fontWeight:700}}>{d}</div>)}
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:2}}>
        {Array.from({length:(new Date(y,m,1).getDay()+6)%7},(_,i)=><div key={`e${i}`}/>)}
        {Array.from({length:dim},(_,i)=>{
          const d=i+1;const key=getDayKey(y,m,d);const sid=empData[key]||null;
          const sh=sid&&shifts[sid];
          const dow=(new Date(y,m,d).getDay()+6)%7;
          const isWeekend=dow>=5;
          const available=filter==='any'||(filter==='work'&&!!sid)||(filter==='free'&&!sid&&!isWeekend);
          const isSel=selected===key;
          return(
            <button key={d} onClick={()=>available&&onPick(key,y,m,d,sid)} disabled={!available} style={{
              aspectRatio:'1',borderRadius:6,cursor:available?'pointer':'default',
              border:`1.5px solid ${isSel?C.accent:sh?sh.color+'33':C.border}`,
              background:isSel?C.accentMut:sh?sh.muted:isWeekend?C.elevated+'50':'transparent',
              opacity:available?1:0.3,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',outline:'none',
            }}>
              <span style={{fontSize:9,fontWeight:isSel?800:500,color:isSel?C.accent:C.text}}>{d}</span>
              {sh&&<span style={{fontSize:6,color:sh.color,fontFamily:'JetBrains Mono',fontWeight:700}}>{sh.id}</span>}
            </button>
          );
        })}
      </div>
    </div>
  );
}

// --- REQUEST MODAL ------------------------------------------------------------
function RequestModal({user,emps,monthSched,shifts,onClose,onSubmit}){
  const [step,setStep]=useState(1);
  const [type,setType]=useState(null);
  const [fromKey,setFromKey]=useState(null);
  const [fromSid,setFromSid]=useState(null);
  const [toKey,setToKey]=useState(null);
  const [toSid,setToSid]=useState(null);
  const [targetEmp,setTargetEmp]=useState(null);
  const [cReason,setCR]=useState('salir_antes');
  const [cHours,setCH]=useState(-1);
  const [wantedShifts,setWS]=useState([]);
  const [note,setNote]=useState('');

  const empData = monthSched[user.id]||{};

  const compat = useMemo(()=>{
    if(!fromKey) return [];
    return emps.filter(e=>{
      if(e.id===user.id||e.role==='coordinator') return false;
      return !!(monthSched[e.id]||{})[fromKey];
    });
  },[fromKey, monthSched, user.id, emps]);

  const canNext=()=>{
    if(step===1) return !!type;
    if(step===2){
      if(type==='swap_person') return !!fromKey&&!!targetEmp;
      if(type==='market') return !!fromKey;
      if(type==='swap_self') return !!fromKey&&!!toKey;
      if(type==='compensation') return !!fromKey;
    }
    return true;
  };

  const submit=()=>{
    const date=new Date().toISOString().slice(0,10);
    if(type==='swap_person'&&targetEmp&&fromKey)
      onSubmit({type:'swap',fromId:user.id,toId:targetEmp.id,fromDate:fromKey,toDate:fromKey,fromShift:fromSid,toShift:(monthSched[targetEmp.id]||{})[fromKey],status:'pending_employee',note,date});
    else if(type==='market'&&fromKey)
      onSubmit({type:'market',fromId:user.id,dateStr:fromKey,shift:fromSid,wantedShifts,note,status:'available',date});
    else if(type==='swap_self'&&fromKey&&toKey)
      onSubmit({type:'self_swap',fromId:user.id,fromDate:fromKey,toDate:toKey,fromShift:fromSid,status:'pending_coordinator',note,date});
    else if(type==='compensation'&&fromKey)
      onSubmit({type:'compensation',fromId:user.id,dateStr:fromKey,hours:cHours,reason:cReason,note,status:'pending_coordinator',date});
    onClose();
  };

  return(
    <div style={{position:'absolute',top:0,left:0,right:0,bottom:0,background:C.bg,display:'flex',flexDirection:'column',zIndex:200,animation:'slideUp 0.22s ease'}}>
      <div style={{padding:'13px 17px',display:'flex',alignItems:'center',gap:11,borderBottom:`1px solid ${C.border}`,flexShrink:0}}>
        <button onClick={step===1?onClose:()=>setStep(s=>s-1)} style={{background:'none',border:'none',cursor:'pointer',color:C.muted,padding:3}}><ChevronLeft size={21}/></button>
        <div style={{flex:1}}>
          <h2 style={{fontSize:15,fontWeight:800,color:C.text}}>Solicitar cambio</h2>
          <p style={{fontSize:10,color:C.muted}}>Paso {step} de 3 - cualquier dia del mes</p>
        </div>
        <div style={{display:'flex',gap:4}}>{[1,2,3].map(s=><div key={s} style={{width:18,height:3,borderRadius:2,background:step>=s?C.accent:C.border,transition:'background 0.2s'}}/>)}</div>
      </div>
      <div style={{flex:1,overflowY:'auto',padding:'17px'}}>
        {step===1&&(
          <div style={{animation:'slideUp 0.2s ease'}}>
            <p style={{color:C.muted,fontSize:13,marginBottom:16}}>Que tipo de cambio necesitas?</p>
            {[
              {id:'swap_person',icon:<ArrowLeftRight size={20} color={C.blue}/>,title:'Cambio con compan/era',desc:'Intercambia turnos con otra persona'},
              {id:'swap_self',icon:<RefreshCw size={20} color={C.purple}/>,title:'Mover mi turno de dia',desc:'Solicita al coordinador cambiar tu turno a cualquier otro dia del mes'},
              {id:'market',icon:<Store size={20} color={C.accent}/>,title:'Publicar en el mercado',desc:'Ofrece tu turno a quien lo necesite'},
              {id:'compensation',icon:<Clock size={20} color={C.green}/>,title:'Compensacion horaria',desc:'Salir antes, entrar tarde o recuperar horas'},
            ].map(o=>(
              <button key={o.id} onClick={()=>{setType(o.id);setStep(2);}} style={{background:C.card,border:`1px solid ${type===o.id?C.accentBrd:C.border}`,borderRadius:13,padding:'14px',textAlign:'left',cursor:'pointer',width:'100%',marginBottom:9,display:'flex',gap:13,alignItems:'flex-start'}}>
                <div style={{width:38,height:38,borderRadius:10,background:C.elevated,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>{o.icon}</div>
                <div><div style={{fontSize:13,fontWeight:700,color:C.text,marginBottom:3}}>{o.title}</div><div style={{fontSize:11,color:C.muted}}>{o.desc}</div></div>
              </button>
            ))}
          </div>
        )}
        {step===2&&(
          <div style={{animation:'slideUp 0.2s ease'}}>
            {type==='swap_person'&&(<>
              <MonthDayPicker monthSched={monthSched} empId={user.id} shifts={shifts} year={CUR_YEAR} month={CUR_MONTH} onPick={(k,y,m,d,sid)=>{setFromKey(k);setFromSid(sid);setTargetEmp(null);}} selected={fromKey} filter='work' label='Tu dia de trabajo'/>
              {fromKey&&(<>
                <SLabel style={{marginTop:14}}>Companero/a disponible ese dia</SLabel>
                {compat.length===0?<p style={{color:C.muted,fontSize:12}}>Nadie trabaja ese dia.</p>:compat.map(emp=>(
                  <button key={emp.id} onClick={()=>setTargetEmp(emp)} style={{background:targetEmp?.id===emp.id?C.accentMut:C.card,border:`1px solid ${targetEmp?.id===emp.id?C.accentBrd:C.border}`,borderRadius:11,padding:'10px 13px',cursor:'pointer',width:'100%',display:'flex',gap:10,alignItems:'center',marginBottom:6}}>
                    <Ava init={emp.init} size={32}/>
                    <div style={{flex:1,textAlign:'left'}}><div style={{fontSize:13,fontWeight:700,color:C.text}}>{emp.name}</div><ShiftPill sid={(monthSched[emp.id]||{})[fromKey]} shifts={shifts} small/></div>
                    {targetEmp?.id===emp.id&&<Check size={15} color={C.accent}/>}
                  </button>
                ))}
              </>)}
            </>)}

            {type==='swap_self'&&(
              <SelfSwapPicker
                monthSched={monthSched} empId={user.id} shifts={shifts}
                fromKey={fromKey} toKey={toKey}
                onFromPick={(k,sid)=>{setFromKey(k);setFromSid(sid);setToKey(null);setToSid(null);}}
                onToPick={(k,sid)=>{setToKey(k);setToSid(sid);}}
              />
            )}

            {type==='market'&&(
              <>
                <MonthDayPicker monthSched={monthSched} empId={user.id} shifts={shifts} year={CUR_YEAR} month={CUR_MONTH} onPick={(k,y,m,d,sid)=>{setFromKey(k);setFromSid(sid);}} selected={fromKey} filter='work' label='Turno que quieres ofrecer'/>
                {fromKey&&(
                  <div style={{marginTop:14,animation:'fadeIn 0.2s ease'}}>
                    <SLabel>Que turno quieres a cambio?</SLabel>
                    <p style={{fontSize:11,color:C.muted,marginBottom:10}}>Selecciona uno o dos turnos especificos, o deja sin marcar para aceptar cualquiera.</p>
                    <div style={{display:'flex',gap:8}}>
                      {Object.values(shifts).filter(s=>s.id!==fromSid).map(s=>{
                        const sel=wantedShifts.includes(s.id);
                        return(
                          <button key={s.id} onClick={()=>setWS(ws=>sel?ws.filter(x=>x!==s.id):ws.length<2?[...ws,s.id]:ws)}
                            style={{flex:1,padding:'10px 6px',borderRadius:10,cursor:'pointer',textAlign:'center',
                              background:sel?s.muted:C.card,
                              border:`1.5px solid ${sel?s.color:C.border}`,
                              transition:'all 0.15s',
                            }}>
                            <div style={{fontFamily:'JetBrains Mono',fontSize:16,fontWeight:800,color:sel?s.color:C.muted}}>{s.id}</div>
                            <div style={{fontSize:10,color:sel?s.color:C.muted,marginTop:2}}>{s.start}–{s.end}</div>
                            <div style={{fontSize:10,color:sel?s.color:C.dim,fontWeight:600}}>{s.netHours}h netas</div>
                            {sel&&<div style={{width:6,height:6,borderRadius:3,background:s.color,margin:'4px auto 0'}}/>}
                          </button>
                        );
                      })}
                    </div>
                    {wantedShifts.length===0&&<p style={{fontSize:10,color:C.dim,marginTop:7,textAlign:'center'}}>Sin preferencia -- cualquier turno sirve</p>}
                    {wantedShifts.length===1&&<p style={{fontSize:10,color:C.yellow,marginTop:7,textAlign:'center'}}>Solo Turno {wantedShifts[0]} -- mayor restriccion, menos opciones</p>}
                    {wantedShifts.length===2&&<p style={{fontSize:10,color:C.green,marginTop:7,textAlign:'center'}}>Turno {wantedShifts[0]} o {wantedShifts[1]} -- mas opciones de intercambio</p>}
                  </div>
                )}
              </>
            )}

            {type==='compensation'&&(<>
              <MonthDayPicker monthSched={monthSched} empId={user.id} shifts={shifts} year={CUR_YEAR} month={CUR_MONTH} onPick={(k,y,m,d,sid)=>{setFromKey(k);setFromSid(sid);}} selected={fromKey} filter='work' label='Dia afectado'/>
              {fromKey&&(<>
                <SLabel style={{marginTop:14}}>Tipo</SLabel>
                {[{id:'salir_antes',l:'Salir antes'},{id:'entrar_tarde',l:'Entrar mas tarde'},{id:'recuperar',l:'Recuperar horas otro dia'}].map(r=>(
                  <button key={r.id} onClick={()=>setCR(r.id)} style={{background:cReason===r.id?C.accentMut:C.card,border:`1px solid ${cReason===r.id?C.accentBrd:C.border}`,borderRadius:9,padding:'9px 13px',cursor:'pointer',width:'100%',marginBottom:6,textAlign:'left',fontSize:13,fontWeight:600,color:cReason===r.id?C.accent:C.text}}>{r.l}</button>
                ))}
                <SLabel>Horas: <span style={{fontFamily:'JetBrains Mono',color:cHours<0?C.red:C.green}}>{cHours>0?'+':''}{cHours}h</span></SLabel>
                <input type="range" min={-4} max={4} step={0.5} value={cHours} onChange={e=>setCH(Number(e.target.value))}/>
              </>)}
            </>)}
          </div>
        )}
        {step===3&&(
          <div style={{animation:'slideUp 0.2s ease'}}>
            <SLabel>Nota (opcional)</SLabel>
            <textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Motivo o detalle del cambio..." style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:11,color:C.text,fontFamily:'Sora',fontSize:13,padding:'12px',width:'100%',height:80,marginBottom:14}}/>
            <Card style={{marginBottom:14}}>
              <p style={{fontSize:11,color:C.muted,marginBottom:8,fontWeight:700}}>Resumen</p>
              <div style={{fontSize:12,color:C.text,lineHeight:1.9}}>
                {type==='swap_person'&&<><b>Cambio con</b> {targetEmp?.name}<br/><b>Dia:</b> {dateStrToLabel(fromKey)}<br/><b>Tu turno:</b> {fromSid} - <b>Su turno:</b> {(monthSched[targetEmp?.id]||{})[fromKey]||'?'}</>}
                {type==='market'&&<><b>Ofreces:</b> {dateStrToLabel(fromKey)}<br/>Turno {fromSid}{wantedShifts.length>0?<><br/><b>Quieres a cambio:</b> Turno {wantedShifts.join(' o Turno ')}</>:<><br/><span style={{color:C.muted}}>A cambio: cualquier turno</span></>}</>}
                {type==='swap_self'&&fromKey&&toKey&&(()=>{
                  const fSh=fromSid&&shifts[fromSid];const tSh=toSid&&shifts[toSid];
                  const isInter=Math.abs(new Date(toKey+'T00:00:00')-new Date(fromKey+'T00:00:00'))>=(7*86400000);
                  return(<>
                    <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:6}}>
                      <div style={{flex:1,background:fSh?fSh.muted:C.elevated,borderRadius:8,padding:'8px',textAlign:'center'}}>
                        <div style={{fontSize:10,color:C.muted,marginBottom:3}}>Origen</div>
                        <div style={{fontSize:12,fontWeight:700,color:C.text}}>{dateStrToLabel(fromKey)}</div>
                        {fSh&&<div style={{fontSize:11,color:fSh.color,fontFamily:'JetBrains Mono',marginTop:2}}>{fSh.id} {fSh.netHours}h</div>}
                        {!fSh&&<div style={{fontSize:11,color:C.dim}}>Libre</div>}
                      </div>
                      <RefreshCw size={16} color={C.accent}/>
                      <div style={{flex:1,background:tSh?tSh.muted:C.elevated,borderRadius:8,padding:'8px',textAlign:'center'}}>
                        <div style={{fontSize:10,color:C.muted,marginBottom:3}}>Destino</div>
                        <div style={{fontSize:12,fontWeight:700,color:C.text}}>{dateStrToLabel(toKey)}</div>
                        {tSh&&<div style={{fontSize:11,color:tSh.color,fontFamily:'JetBrains Mono',marginTop:2}}>{tSh.id} {tSh.netHours}h</div>}
                        {!tSh&&<div style={{fontSize:11,color:C.dim}}>Libre</div>}
                      </div>
                    </div>
                    {isInter&&<p style={{fontSize:10,color:C.accent}}>Cambio entre semanas distintas - el coordinador evaluara el impacto en el objetivo mensual.</p>}
                  </>);
                })()}
                {type==='compensation'&&<><b>Compensacion:</b> {cHours>0?'+':''}{cHours}h<br/><b>Dia:</b> {dateStrToLabel(fromKey)}</>}
              </div>
            </Card>
            <div style={{background:C.yellowMut,border:`1px solid ${C.yellow}33`,borderRadius:10,padding:'9px 13px'}}>
              <p style={{fontSize:11,color:C.yellow}}>Requiere aprobacion del coordinador antes de aplicarse.</p>
            </div>
          </div>
        )}
      </div>
      <div style={{padding:'12px 17px',borderTop:`1px solid ${C.border}`,flexShrink:0}}>
        {step<3?<Btn onClick={()=>setStep(s=>s+1)} disabled={!canNext()}>Continuar</Btn>:<Btn onClick={submit}>Enviar solicitud</Btn>}
      </div>
    </div>
  );
}

// --- REQUESTS -----------------------------------------------------------------
function RequestsScreen({user,emps,requests,history,shifts,onApprove,onReject,onAcceptSwap}){
  const isCoord=user.role==='coordinator';
  const [tab,setTab]=useState('pending');
  const mine=requests.filter(r=>r.fromId===user.id||r.toId===user.id);
  const pending=isCoord?requests.filter(r=>r.status==='pending_coordinator'):mine;
  const empName=id=>emps.find(e=>e.id===id)?.name||'?';
  const empInit=id=>emps.find(e=>e.id===id)?.init||'??';

  const dLabel=(r)=>{
    if(r.dateStr) return dateStrToLabel(r.dateStr);
    if(r.fromDate) return dateStrToLabel(r.fromDate);
    if(r.fromDay!=null) return `Dia ${r.fromDay+1}`;
    return '--';
  };

  const TIcon=({type})=>{
    if(type==='swap'||type==='self_swap')return <ArrowLeftRight size={13} color={C.blue}/>;
    if(type==='market')return <Store size={13} color={C.accent}/>;
    if(type==='compensation')return <Clock size={13} color={C.green}/>;
    return null;
  };

  const ReqCard=({r})=>{
    const myTurn=r.toId===user.id&&r.status==='pending_employee';
    const coTurn=isCoord&&r.status==='pending_coordinator';
    return(
      <Card style={{marginBottom:9,borderColor:myTurn?C.accentBrd:C.border}}>
        <div style={{display:'flex',gap:10,alignItems:'flex-start',marginBottom:myTurn||coTurn?10:0}}>
          <Ava init={empInit(r.fromId)} size={32}/>
          <div style={{flex:1}}>
            <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap',marginBottom:3}}>
              <TIcon type={r.type}/>
              <span style={{fontSize:12,fontWeight:700,color:C.text}}>{empName(r.fromId)}</span>
              {r.toId&&<><span style={{color:C.muted,fontSize:11}}>-</span><span style={{fontSize:12,fontWeight:700,color:C.text}}>{empName(r.toId)}</span></>}
              <Badge variant={STATUS_VAR[r.status]||'warn'}>{STATUS_LABEL[r.status]||r.status}</Badge>
            </div>
            <div style={{fontSize:11,color:C.muted,marginBottom:r.note?3:0}}>
              {r.type==='swap'&&`${dLabel(r)} - ${r.fromShift||'?'} con ${r.toShift||'?'}`}
              {r.type==='market'&&`Ofrece ${dLabel(r)} - Turno ${r.shift||'?'}`}
              {r.type==='compensation'&&`${dLabel(r)} - ${r.hours>0?'+':''}${r.hours}h`}
              {r.type==='self_swap'&&`${dateStrToLabel(r.fromDate)} a ${dateStrToLabel(r.toDate)}`}
            </div>
            {r.note&&<div style={{fontSize:11,color:C.muted,fontStyle:'italic'}}>"{r.note}"</div>}
            <div style={{fontSize:10,color:C.dim,marginTop:3}}>{r.date}</div>
          </div>
        </div>
        {(myTurn||coTurn)&&(
          <div style={{display:'flex',gap:7}}>
            <Btn small secondary danger onClick={()=>onReject(r.id)} style={{flex:1}}>Rechazar</Btn>
            <Btn small onClick={()=>myTurn?onAcceptSwap(r.id):onApprove(r.id)} style={{flex:1}}>{myTurn?'Aceptar':'Aprobar'}</Btn>
          </div>
        )}
      </Card>
    );
  };

  const HistCard=({r})=>(
    <Card style={{marginBottom:9}}>
      <div style={{display:'flex',gap:10,alignItems:'center'}}>
        <Ava init={empInit(r.fromId)} size={30}/>
        <div style={{flex:1}}><div style={{fontSize:12,fontWeight:700,color:C.text,marginBottom:2}}>{r.desc}</div><div style={{fontSize:11,color:C.muted}}>{r.date}</div></div>
        <Badge variant={r.status==='applied'?'blue':r.status==='rejected'?'red':'warn'}>{r.status==='applied'?'Aplicado':'Rechazado'}</Badge>
      </div>
    </Card>
  );

  return(
    <div style={{padding:'0 15px'}}>
      <div style={{display:'flex',gap:7,marginBottom:13}}>
        {[['pending','Pendientes'],['history','Historial']].map(([v,l])=>(
          <button key={v} onClick={()=>setTab(v)} style={{flex:1,padding:'8px',borderRadius:10,cursor:'pointer',background:tab===v?C.accentMut:C.card,border:`1px solid ${tab===v?C.accentBrd:C.border}`,color:tab===v?C.accent:C.muted,fontFamily:'Sora',fontSize:12,fontWeight:700}}>{l}</button>
        ))}
      </div>
      {tab==='pending'?(
        pending.length===0
          ?<div style={{textAlign:'center',paddingTop:40}}><CheckCircle size={30} color={C.green} style={{margin:'0 auto 10px'}}/><p style={{color:C.muted,fontSize:13}}>Sin solicitudes pendientes</p></div>
          :pending.map(r=><ReqCard key={r.id} r={r}/>)
      ):(
        history.length===0?<p style={{color:C.muted,textAlign:'center',marginTop:32,fontSize:13}}>Sin historial</p>:history.map(r=><HistCard key={r.id} r={r}/>)
      )}
    </div>
  );
}

// --- MARKET -------------------------------------------------------------------
function MarketScreen({user,emps,requests,shifts,monthSched,onClaim}){
  const avail=requests.filter(r=>r.type==='market'&&r.status==='available'&&r.fromId!==user.id);
  const empName=id=>emps.find(e=>e.id===id)?.name||'?';
  const empInit=id=>emps.find(e=>e.id===id)?.init||'??';
  return(
    <div style={{padding:'0 15px'}}>
      <div style={{marginBottom:13}}>
        <h2 style={{fontSize:16,fontWeight:800,color:C.text}}>Mercado de turnos</h2>
        <p style={{fontSize:12,color:C.muted,marginTop:2}}>{MONTHS_CAP[CUR_MONTH]} {CUR_YEAR}</p>
      </div>
      {avail.length===0?(
        <div style={{textAlign:'center',marginTop:48}}>
          <Store size={32} color={C.dim} style={{margin:'0 auto 12px'}}/>
          <p style={{color:C.muted,fontSize:13,fontWeight:600}}>Sin turnos disponibles</p>
        </div>
      ):avail.map(r=>{
        const myData=monthSched[user.id]||{};
        const key=r.dateStr;
        const myOnThatDay=!!myData[key];
        const myShiftThatDay=myData[key]||null;
        const sh=shifts[r.shift];
        const wanted=r.wantedShifts||[];
        const shiftMatch=wanted.length===0||(myShiftThatDay&&wanted.includes(myShiftThatDay));
        const canClaim=!myOnThatDay||(myShiftThatDay&&shiftMatch);
        return(
          <Card key={r.id} style={{marginBottom:9}}>
            <div style={{display:'flex',gap:10,alignItems:'flex-start',marginBottom:10}}>
              <Ava init={empInit(r.fromId)} size={32}/>
              <div style={{flex:1}}>
                <div style={{fontSize:13,fontWeight:700,color:C.text,marginBottom:5}}>{empName(r.fromId)}</div>
                <ShiftPill sid={r.shift} shifts={shifts}/>
                <div style={{fontSize:11,color:C.muted,marginTop:5}}>
                  <span style={{fontWeight:600,color:C.text}}>{dateStrToLabel(key)}</span>
                  {sh&&<><br/><span>{sh.netHours}h netas</span>{sh.breakMin>0&&<><span style={{color:C.dim}}> - </span><Coffee size={10} color={C.muted}/><span>{breakLabel(sh.breakMin)}</span></>}</>}
                </div>
                {r.note&&<div style={{fontSize:11,color:C.muted,fontStyle:'italic',marginTop:3}}>"{r.note}"</div>}
                {wanted.length>0&&(
                  <div style={{marginTop:8,padding:'7px 10px',background:C.elevated,borderRadius:8,display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}}>
                    <span style={{fontSize:10,color:C.muted,fontWeight:700}}>QUIERE A CAMBIO:</span>
                    {wanted.map(sid=>{
                      const ws=shifts[sid];
                      const myMatch=myShiftThatDay===sid;
                      return ws?(
                        <span key={sid} style={{background:myMatch?ws.muted:C.card,color:myMatch?ws.color:C.muted,border:`1px solid ${myMatch?ws.color+'55':C.border}`,borderRadius:6,padding:'2px 8px',fontSize:10,fontWeight:700,fontFamily:'JetBrains Mono'}}>
                          {sid} {myMatch&&'✓'}
                        </span>
                      ):null;
                    })}
                    {myShiftThatDay&&!shiftMatch&&<span style={{fontSize:10,color:C.red}}>Tu turno ({myShiftThatDay}) no encaja</span>}
                    {myShiftThatDay&&shiftMatch&&<span style={{fontSize:10,color:C.green}}>Tienes el turno que pide!</span>}
                  </div>
                )}
                {myShiftThatDay&&(
                  <div style={{marginTop:6,fontSize:10,color:C.muted}}>
                    Tu turno ese dia: <span style={{fontFamily:'JetBrains Mono',color:shifts[myShiftThatDay]?.color||C.text,fontWeight:700}}>{myShiftThatDay}</span>
                    {shiftMatch&&wanted.length>0&&<span style={{color:C.green}}> -- intercambio posible</span>}
                  </div>
                )}
              </div>
              {!myOnThatDay&&<Badge variant="green">Libre</Badge>}
              {myOnThatDay&&shiftMatch&&wanted.length>0&&<Badge variant="green">Encaja</Badge>}
              {myOnThatDay&&!shiftMatch&&<Badge variant="red">No encaja</Badge>}
            </div>
            {!myOnThatDay
              ?<Btn small onClick={()=>onClaim(r.id,user.id,null)}>Solicitar este turno</Btn>
              :shiftMatch&&wanted.length>0
                ?<Btn small onClick={()=>onClaim(r.id,user.id,myShiftThatDay)}>Intercambiar (ofrezco turno {myShiftThatDay})</Btn>
                :<Btn small disabled>{myOnThatDay&&!shiftMatch?'Tu turno no encaja con lo que pide':'Ya tienes turno ese dia'}</Btn>
            }
          </Card>
        );
      })}
    </div>
  );
}

// --- METRICS ------------------------------------------------------------------
function MetricsScreen({emps,monthSched,shifts,requests,history}){
  const employees=emps.filter(e=>e.role==='employee');
  const pending=requests.filter(r=>r.status==='pending_coordinator');
  const allReqs=[...requests,...history];
  const expH=expectedMonthHours(CUR_YEAR,CUR_MONTH);
  return(
    <div style={{padding:'0 15px'}}>
      <div style={{marginBottom:10}}>
        <p style={{fontSize:13,fontWeight:700,color:C.text}}>{MONTHS_CAP[CUR_MONTH]} {CUR_YEAR}</p>
        <p style={{fontSize:11,color:C.muted}}>Objetivo mensual: {expH}h por persona (~40h/sem)</p>
      </div>
      <div style={{display:'flex',gap:8,marginBottom:13}}>
        {[{v:pending.length,col:C.accent,l:'Pendientes'},{v:allReqs.length,col:C.blue,l:'Cambios'},{v:employees.length,col:C.green,l:'Empleados'}].map(s=>(
          <Card key={s.l} style={{flex:1,textAlign:'center'}}>
            <div style={{fontFamily:'JetBrains Mono',fontSize:22,fontWeight:700,color:s.col}}>{s.v}</div>
            <div style={{fontSize:10,color:C.muted,marginTop:2}}>{s.l}</div>
          </Card>
        ))}
      </div>
      <SLabel>Horas netas por empleado - {MONTHS_CAP[CUR_MONTH]}</SLabel>
      {employees.map(emp=>{
        const h=monthNetHours(emp.id,monthSched,shifts,CUR_YEAR,CUR_MONTH);
        const dev=Math.round((h-expH)*10)/10;
        const pct=Math.min(100,Math.round((h/expH)*100));
        const col=Math.abs(dev)<expH*0.05?C.green:Math.abs(dev)<expH*0.12?C.yellow:C.red;
        const empReqs=allReqs.filter(r=>r.fromId===emp.id||r.toId===emp.id).length;
        return(
          <Card key={emp.id} style={{marginBottom:7}}>
            <div style={{display:'flex',alignItems:'center',gap:9,marginBottom:6}}>
              <Ava init={emp.init} size={28}/>
              <div style={{flex:1}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
                  <span style={{fontSize:12,fontWeight:700,color:C.text}}>{emp.name}</span>
                  <div style={{display:'flex',gap:8,alignItems:'center'}}>
                    <span style={{fontFamily:'JetBrains Mono',fontSize:11,color:col}}>{dev>=0?'+':''}{dev}h</span>
                    <span style={{fontFamily:'JetBrains Mono',fontSize:13,fontWeight:700,color:C.text}}>{h}h</span>
                  </div>
                </div>
                <div style={{height:4,background:C.elevated,borderRadius:2,marginTop:6}}><div style={{height:4,borderRadius:2,background:col,width:`${pct}%`,transition:'width 0.3s'}}/></div>
              </div>
            </div>
            <div style={{display:'flex',gap:10,fontSize:10,color:C.muted}}>
              <span>{empReqs} cambios</span>
              <span style={{color:C.dim}}>-</span>
              <span style={{color:col}}>obj. {expH}h mes</span>
            </div>
          </Card>
        );
      })}
      <div style={{marginTop:8,padding:'8px 12px',background:C.elevated,borderRadius:9}}>
        <p style={{fontSize:10,color:C.muted,lineHeight:1.7}}>
          <b style={{color:C.text}}>Descansos aplicados:</b><br/>
          A (08-14): sin descanso = 6h netas - B (08-15:30): 30min = 7h netas - C (09-20): 60min = 10h netas
        </p>
      </div>
    </div>
  );
}

// --- SCHEDULE EDITOR ----------------------------------------------------------
function CellPicker({sid,shifts,onChange}){
  const [open,setOpen]=useState(false);
  const s=sid&&shifts[sid];
  return(
    <div style={{flex:1,position:'relative'}}>
      <button onClick={()=>setOpen(o=>!o)} style={{width:'100%',height:24,borderRadius:4,cursor:'pointer',background:s?s.muted:C.elevated,border:`1px solid ${s?s.color+'44':C.border}`,display:'flex',alignItems:'center',justifyContent:'center'}}>
        {s?<span style={{fontSize:9,fontWeight:800,color:s.color,fontFamily:'JetBrains Mono'}}>{s.id}</span>:<span style={{fontSize:9,color:C.dim}}>--</span>}
      </button>
      {open&&(
        <div style={{position:'absolute',top:28,left:0,zIndex:100,background:C.card,border:`1px solid ${C.border}`,borderRadius:8,padding:4,minWidth:100,boxShadow:'0 8px 24px #00000060'}}>
          <button onClick={()=>{onChange(null);setOpen(false);}} style={{display:'block',width:'100%',textAlign:'left',padding:'5px 8px',background:'none',border:'none',cursor:'pointer',color:C.muted,fontSize:11,borderRadius:5}}>-- Libre</button>
          {Object.values(shifts).map(sh=>(
            <button key={sh.id} onClick={()=>{onChange(sh.id);setOpen(false);}} style={{display:'block',width:'100%',textAlign:'left',padding:'5px 8px',background:'none',border:'none',cursor:'pointer',color:sh.color,fontSize:11,fontWeight:700,borderRadius:5,fontFamily:'JetBrains Mono'}}>
              {sh.id} {sh.start}-{sh.end} {sh.netHours}h
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function ScheduleEditor({emps,monthSched,shifts,onUpdateMonthSched,onUpdateShifts}){
  const [activeTab,setActiveTab]=useState('import');
  const [editShifts,setES]=useState(false);
  const [draft,setDraft]=useState(JSON.parse(JSON.stringify(shifts)));
  const [nId,setNId]=useState('');const [nName,setNName]=useState('');
  const [nStart,setNS]=useState('08:00');const [nEnd,setNE]=useState('17:00');const [nBreak,setNB]=useState(0);
  const [impErr,setIE]=useState('');const [impOk,setIO]=useState('');
  const [gridYear,setGY]=useState(CUR_YEAR);const [gridMonth,setGM]=useState(CUR_MONTH);
  const [selEmp,setSelEmp]=useState(emps.filter(e=>e.role==='employee')[0]?.id||null);
  const fileRef=useRef();
  const employees=emps.filter(e=>e.role==='employee');
  const SH_COLS=['#58A6FF','#3FB950','#E3A007','#F85149','#BC8CFF','#F78166','#79C0FF','#56D364'];
  const BREAK_OPTS=[0,15,30,45,60,90];

  const updCell=(eId,key,val)=>{
    const ns={...monthSched};
    if(!ns[eId]) ns[eId]={};
    ns[eId]={...ns[eId],[key]:val||null};
    onUpdateMonthSched(ns);
  };

  const handleFile=e=>{
    const f=e.target.files[0];if(!f)return;setIE('');setIO('');
    const rd=new FileReader();
    rd.onload=ev=>{
      try{
        const wb=XLSX.read(ev.target.result,{type:'binary'});
        const ws=wb.Sheets[wb.SheetNames[0]];
        const data=XLSX.utils.sheet_to_json(ws,{header:1});
        if(!data||data.length<2){setIE('El archivo esta vacio o no tiene formato valido.');return;}
        const header=data[0];
        const ns={...monthSched};let matched=0;
        const useFullDates = header[1]&&String(header[1]).includes('-');
        for(let i=1;i<data.length;i++){
          const row=data[i];if(!row||!row[0])continue;
          const s=String(row[0]).trim();
          const emp=emps.find(e=>e.name.toLowerCase()===s.toLowerCase()||String(e.id)===s||e.init.toLowerCase()===s.toLowerCase());
          if(!emp)continue;
          if(!ns[emp.id])ns[emp.id]={};
          for(let c=1;c<header.length;c++){
            const hCell=header[c];
            let key;
            if(useFullDates){key=String(hCell).trim();}
            else{
              const dayN=parseInt(hCell);if(isNaN(dayN))continue;
              key=getDayKey(CUR_YEAR,CUR_MONTH,dayN);
            }
            const v=row[c]?String(row[c]).trim().toUpperCase():null;
            ns[emp.id][key]=v&&shifts[v]?v:null;
          }
          matched++;
        }
        if(matched===0)setIE('No se encontraron empleados. Verifica nombres, iniciales o IDs.');
        else{onUpdateMonthSched(ns);setIO(`Importados ${matched} empleados correctamente`);}
      }catch(err){setIE('Error al leer el archivo: '+err.message);}
    };
    rd.readAsBinaryString(f);e.target.value='';
  };

  const exportTpl=()=>{
    const dim=daysInMonth(CUR_YEAR,CUR_MONTH);
    const header=['Empleado'];
    for(let d=1;d<=dim;d++) header.push(d);
    const rows=[header];
    employees.forEach(emp=>{
      const empData=monthSched[emp.id]||{};
      const row=[emp.name];
      for(let d=1;d<=dim;d++){
        const key=getDayKey(CUR_YEAR,CUR_MONTH,d);
        row.push(empData[key]||'');
      }
      rows.push(row);
    });
    const dowRow=['(dia semana)'];
    for(let d=1;d<=dim;d++){
      const dow=(new Date(CUR_YEAR,CUR_MONTH,d).getDay()+6)%7;
      dowRow.push(DAYS[dow]);
    }
    rows.splice(1,0,dowRow);
    const ws=XLSX.utils.aoa_to_sheet(rows);
    ws['!cols']=[{wch:18},...Array(dim).fill({wch:4})];
    const wb=XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb,ws,`Horario ${MONTHS_CAP[CUR_MONTH]}`);
    XLSX.writeFile(wb,`horario_${MONTHS[CUR_MONTH]}_${CUR_YEAR}.xlsx`);
  };

  const addShift=()=>{
    if(!nId||draft[nId])return;
    const gross=calcHours(nStart,nEnd);const net=Math.max(0,Math.round((gross-nBreak/60)*10)/10);
    const col=SH_COLS[Object.keys(draft).length%SH_COLS.length];
    setDraft(s=>({...s,[nId]:{id:nId,name:nName||`Turno ${nId}`,start:nStart,end:nEnd,hours:gross,breakMin:nBreak,netHours:net,color:col,muted:`${col}26`}}));
    setNId('');setNName('');setNS('08:00');setNE('17:00');setNB(0);
  };
  const rmShift=id=>{const d={...draft};delete d[id];setDraft(d);};
  const save=()=>{onUpdateShifts(draft);setES(false);};
  const updDraft=(id,field,val)=>{
    setDraft(d=>{const sh={...d[id],[field]:val};const gross=calcHours(sh.start,sh.end);sh.hours=gross;sh.netHours=Math.max(0,Math.round((gross-(sh.breakMin||0)/60)*10)/10);return{...d,[id]:sh};});
  };
  const TI=(val,onChange)=><input type="time" value={val} onChange={onChange} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:8,padding:'7px 10px',color:C.text,fontSize:13,fontFamily:'JetBrains Mono',width:'100%',outline:'none'}}/>;

  const navGrid=(dir)=>{let m=gridMonth+dir,y=gridYear;if(m<0){m=11;y--;}if(m>11){m=0;y++;}setGM(m);setGY(y);};
  const gridDim=daysInMonth(gridYear,gridMonth);

  return(
    <div style={{padding:'0 15px'}}>
      <div style={{display:'flex',gap:7,marginBottom:13}}>
        {[['import','Importar'],['grid','Cuadrante'],['shifttypes','Turnos']].map(([v,l])=>(
          <button key={v} onClick={()=>setActiveTab(v)} style={{flex:1,padding:'7px',borderRadius:9,cursor:'pointer',fontSize:11,fontWeight:700,background:activeTab===v?C.accentMut:C.card,border:`1px solid ${activeTab===v?C.accentBrd:C.border}`,color:activeTab===v?C.accent:C.muted}}>{l}</button>
        ))}
      </div>

      {activeTab==='import'&&(
        <div>
          <Card style={{marginBottom:13}}>
            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12}}>
              <div style={{width:38,height:38,borderRadius:10,background:C.accentMut,display:'flex',alignItems:'center',justifyContent:'center'}}><Upload size={18} color={C.accent}/></div>
              <div>
                <p style={{fontSize:13,fontWeight:700,color:C.text}}>Importar horario mensual</p>
                <p style={{fontSize:11,color:C.muted}}>Excel con todos los dias del mes</p>
              </div>
            </div>
            <div style={{background:C.elevated,borderRadius:9,padding:'10px 12px',marginBottom:12}}>
              <p style={{fontSize:11,fontWeight:700,color:C.text,marginBottom:5}}>Formato de columnas:</p>
              <p style={{fontSize:10,color:C.muted,lineHeight:1.7}}>
                <b style={{color:C.text}}>Fila 1:</b> Empleado | 1 | 2 | 3 | ... | {daysInMonth(CUR_YEAR,CUR_MONTH)}<br/>
                <b style={{color:C.text}}>Fila 2:</b> (dia semana - referencia)<br/>
                <b style={{color:C.text}}>Fila 3+:</b> Nombre | A/B/C/vacio por dia<br/>
                Empleado: nombre completo, iniciales o ID numerico
              </p>
            </div>
            {impErr&&<div style={{background:C.redMut,border:`1px solid ${C.red}44`,borderRadius:9,padding:'9px 12px',marginBottom:10,fontSize:12,color:C.red}}>{impErr}</div>}
            {impOk&&<div style={{background:C.greenMut,border:`1px solid ${C.green}44`,borderRadius:9,padding:'9px 12px',marginBottom:10,fontSize:12,color:C.green}}>{impOk}</div>}
            <input type="file" accept=".xlsx,.xls,.csv" ref={fileRef} style={{display:'none'}} onChange={handleFile}/>
            <div style={{display:'flex',flexDirection:'column',gap:8}}>
              <Btn onClick={()=>fileRef.current?.click()} style={{display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
                <Upload size={16}/> Seleccionar Excel mensual
              </Btn>
              <Btn secondary onClick={exportTpl} style={{display:'flex',alignItems:'center',justifyContent:'center',gap:8}}>
                <Download size={16}/> Descargar plantilla {MONTHS_CAP[CUR_MONTH]}
              </Btn>
            </div>
          </Card>
          <Card>
            <p style={{fontSize:11,fontWeight:700,color:C.text,marginBottom:8}}>Ejemplo de formato</p>
            <div style={{overflowX:'auto'}}>
              <table style={{borderCollapse:'collapse',fontSize:9,fontFamily:'JetBrains Mono',whiteSpace:'nowrap'}}>
                <tbody>
                  {[
                    ['Empleado','1','2','3','4','5','6','7'],
                    ['(dia)','Lun','Mar','Mie','Jue','Vie','Sab','Dom'],
                    ['Ana Garcia','A','A','B','','C','',''],
                    ['CL','B','B','','A','A','',''],
                    ['3','C','','A','A','B','',''],
                  ].map((row,i)=>(
                    <tr key={i}>{row.map((cell,j)=><td key={j} style={{padding:'3px 7px',border:`1px solid ${C.border}`,color:i===0?C.accent:i===1?C.muted:C.text,background:i===0?C.accentMut:i===1?C.elevated:'transparent',fontWeight:i===0||i===1?700:400}}>{cell||<span style={{color:C.dim}}>--</span>}</td>)}</tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p style={{fontSize:10,color:C.muted,marginTop:8}}>Al importar se actualizan los horarios de TODOS los usuarios para ese mes.</p>
          </Card>
        </div>
      )}

      {activeTab==='grid'&&(
        <>
          <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:10}}>
            <button onClick={()=>navGrid(-1)} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:8,padding:'5px 9px',cursor:'pointer',color:C.muted}}><ChevronLeft size={15}/></button>
            <span style={{fontSize:13,fontWeight:700,color:C.text}}>{MONTHS_CAP[gridMonth]} {gridYear}</span>
            <button onClick={()=>navGrid(1)} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:8,padding:'5px 9px',cursor:'pointer',color:C.muted}}><ChevronRight size={15}/></button>
          </div>
          <div style={{display:'flex',gap:5,overflowX:'auto',paddingBottom:6,marginBottom:8}}>
            {employees.map(e=>(
              <button key={e.id} onClick={()=>setSelEmp(e.id)} style={{flexShrink:0,background:selEmp===e.id?C.accentMut:C.elevated,border:`1px solid ${selEmp===e.id?C.accentBrd:C.border}`,borderRadius:8,padding:'5px 9px',cursor:'pointer'}}>
                <span style={{fontSize:10,fontWeight:700,color:selEmp===e.id?C.accent:C.muted,whiteSpace:'nowrap'}}>{e.name.split(' ')[0]}</span>
              </button>
            ))}
          </div>
          {selEmp&&(()=>{
            const emp=emps.find(e=>e.id===selEmp);
            const empData=monthSched[selEmp]||{};
            const netH=monthNetHours(selEmp,monthSched,shifts,gridYear,gridMonth);
            return(
              <div>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:8}}>
                  <div style={{display:'flex',alignItems:'center',gap:7}}><Ava init={emp.init} size={24}/><span style={{fontSize:12,fontWeight:700,color:C.text}}>{emp.name}</span></div>
                  <span style={{fontFamily:'JetBrains Mono',fontSize:11,color:C.muted}}>{netH}h netas</span>
                </div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:2,marginBottom:3}}>
                  {DAYS.map(d=><div key={d} style={{textAlign:'center',fontSize:8,color:C.muted,fontWeight:700}}>{d}</div>)}
                </div>
                <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:2}}>
                  {Array.from({length:(new Date(gridYear,gridMonth,1).getDay()+6)%7},(_,i)=><div key={`e${i}`}/>)}
                  {Array.from({length:gridDim},(_,i)=>{
                    const d=i+1;const key=getDayKey(gridYear,gridMonth,d);const sid=empData[key]||null;
                    return(
                      <div key={d} style={{position:'relative'}}>
                        <CellPicker sid={sid} shifts={shifts} onChange={val=>updCell(selEmp,key,val)}/>
                        <div style={{textAlign:'center',fontSize:7,color:C.muted,marginTop:1}}>{d}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}
        </>
      )}

      {activeTab==='shifttypes'&&(
        <div>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:11}}>
            <p style={{fontSize:13,fontWeight:700,color:C.text}}>Tipos de turno</p>
            {editShifts
              ?<div style={{display:'flex',gap:7}}>
                <button onClick={()=>{setDraft(JSON.parse(JSON.stringify(shifts)));setES(false);}} style={{background:'none',border:'none',cursor:'pointer',color:C.muted}}><X size={16}/></button>
                <button onClick={save} style={{background:C.accentMut,border:`1px solid ${C.accentBrd}`,borderRadius:8,padding:'5px 12px',cursor:'pointer',color:C.accent,fontSize:12,fontWeight:700}}><Save size={12} style={{marginRight:4,verticalAlign:'middle'}}/>Guardar</button>
              </div>
              :<button onClick={()=>setES(true)} style={{background:C.accentMut,border:`1px solid ${C.accentBrd}`,borderRadius:8,padding:'5px 12px',cursor:'pointer',color:C.accent,fontSize:12,fontWeight:700}}><Edit3 size={12} style={{marginRight:4,verticalAlign:'middle'}}/>Editar</button>
            }
          </div>
          {Object.values(draft).map(s=>(
            <Card key={s.id} style={{marginBottom:8}}>
              {editShifts?(
                <div>
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:10}}>
                    <span style={{fontFamily:'JetBrains Mono',fontSize:14,fontWeight:700,color:s.color}}>{s.id} - {s.name}</span>
                    <button onClick={()=>rmShift(s.id)} style={{background:C.redMut,border:'none',borderRadius:6,padding:'4px 8px',cursor:'pointer',color:C.red}}><Trash2 size={12}/></button>
                  </div>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:7,marginBottom:8}}>
                    <div><SLabel>Inicio</SLabel>{TI(s.start,e=>updDraft(s.id,'start',e.target.value))}</div>
                    <div><SLabel>Fin</SLabel>{TI(s.end,e=>updDraft(s.id,'end',e.target.value))}</div>
                  </div>
                  <SLabel>Descanso</SLabel>
                  <div style={{display:'flex',gap:5,flexWrap:'wrap',marginBottom:6}}>
                    {BREAK_OPTS.map(m=><button key={m} onClick={()=>updDraft(s.id,'breakMin',m)} style={{padding:'5px 9px',borderRadius:7,fontSize:11,fontWeight:700,cursor:'pointer',background:s.breakMin===m?C.accentMut:C.elevated,border:`1px solid ${s.breakMin===m?C.accentBrd:C.border}`,color:s.breakMin===m?C.accent:C.muted}}>{m===0?'Sin descanso':`${m}min`}</button>)}
                  </div>
                  <div style={{fontSize:11,color:C.muted,fontFamily:'JetBrains Mono'}}>Bruto: {s.hours}h - <span style={{color:C.green,fontWeight:700}}>Neto: {s.netHours}h</span></div>
                </div>
              ):(
                <div style={{display:'flex',alignItems:'center',gap:10}}>
                  <div style={{width:32,height:32,borderRadius:8,background:`${s.color}22`,border:`1.5px solid ${s.color}50`,display:'flex',alignItems:'center',justifyContent:'center',fontFamily:'JetBrains Mono',fontWeight:700,fontSize:14,color:s.color}}>{s.id}</div>
                  <div style={{flex:1}}>
                    <div style={{fontSize:13,fontWeight:700,color:C.text}}>{s.name}</div>
                    <div style={{fontSize:11,color:C.muted,fontFamily:'JetBrains Mono',display:'flex',gap:6,alignItems:'center',flexWrap:'wrap'}}>
                      <span>{s.start}-{s.end}</span><span style={{color:C.dim}}>-</span>
                      <span style={{color:C.green,fontWeight:700}}>{s.netHours}h netas</span>
                      {s.breakMin>0&&<><span style={{color:C.dim}}>-</span><Coffee size={10} color={C.muted}/><span>{breakLabel(s.breakMin)}</span></>}
                    </div>
                  </div>
                </div>
              )}
            </Card>
          ))}
          {editShifts&&(
            <Card style={{border:`1px dashed ${C.accentBrd}`,marginTop:4}}>
              <p style={{fontSize:11,fontWeight:700,color:C.accent,marginBottom:10}}>Anadir tipo de turno</p>
              <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:7,marginBottom:8}}>
                <div><SLabel>Letra/ID</SLabel><input value={nId} onChange={e=>setNId(e.target.value.toUpperCase().slice(0,2))} maxLength={2} placeholder="D" style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:8,padding:'7px 10px',color:C.text,fontSize:13,fontFamily:'JetBrains Mono',width:'100%',outline:'none'}}/></div>
                <div><SLabel>Nombre</SLabel><input value={nName} onChange={e=>setNName(e.target.value)} placeholder="Turno D" style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:8,padding:'7px 10px',color:C.text,fontSize:13,width:'100%',outline:'none'}}/></div>
                <div><SLabel>Inicio</SLabel>{TI(nStart,e=>setNS(e.target.value))}</div>
                <div><SLabel>Fin</SLabel>{TI(nEnd,e=>setNE(e.target.value))}</div>
              </div>
              <SLabel>Descanso</SLabel>
              <div style={{display:'flex',gap:5,flexWrap:'wrap',marginBottom:10}}>
                {BREAK_OPTS.map(m=><button key={m} onClick={()=>setNB(m)} style={{padding:'5px 9px',borderRadius:7,fontSize:11,fontWeight:700,cursor:'pointer',background:nBreak===m?C.accentMut:C.elevated,border:`1px solid ${nBreak===m?C.accentBrd:C.border}`,color:nBreak===m?C.accent:C.muted}}>{m===0?'Sin descanso':`${m}min`}</button>)}
              </div>
              <div style={{fontSize:11,color:C.muted,marginBottom:10,fontFamily:'JetBrains Mono'}}>
                Bruto: {calcHours(nStart,nEnd)}h - Neto: <span style={{color:C.green,fontWeight:700}}>{Math.max(0,Math.round((calcHours(nStart,nEnd)-nBreak/60)*10)/10)}h</span>
              </div>
              <Btn small onClick={addShift} disabled={!nId||!!draft[nId]}>{draft[nId]?'ID ya existe':'Anadir turno'}</Btn>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}

// --- NOTIFS -------------------------------------------------------------------
function NotifsScreen({user,emps,requests,monthSched,shifts}){
  const isCoord=user.role==='coordinator';
  const employees=emps.filter(e=>e.role==='employee');
  const expH=expectedMonthHours(CUR_YEAR,CUR_MONTH);
  const alerts=employees.map(emp=>{
    const h=monthNetHours(emp.id,monthSched,shifts,CUR_YEAR,CUR_MONTH);
    const dev=Math.round((h-expH)*10)/10;
    if(Math.abs(dev)<expH*0.05)return null;
    return{id:emp.id,name:emp.name,init:emp.init,hours:h,dev,severity:Math.abs(dev)>=expH*0.12?'red':'yellow'};
  }).filter(Boolean);
  const myPend=requests.filter(r=>isCoord?r.status==='pending_coordinator':(r.fromId===user.id||r.toId===user.id)&&r.status.includes('pending'));
  return(
    <div style={{padding:'0 15px'}}>
      {myPend.length>0&&(<>
        <SLabel>Solicitudes pendientes</SLabel>
        {myPend.map(r=>(
          <Card key={r.id} style={{marginBottom:8,borderColor:C.accentBrd}}>
            <div style={{display:'flex',gap:8,alignItems:'center'}}>
              <Bell size={16} color={C.accent}/>
              <div style={{flex:1}}>
                <div style={{fontSize:12,fontWeight:700,color:C.text}}>{r.type==='swap'?'Solicitud de cambio':r.type==='market'?'Turno en mercado':r.type==='compensation'?'Compensacion horaria':'Cambio de dia'}</div>
                <div style={{fontSize:11,color:C.muted,marginTop:2}}>{emps.find(e=>e.id===r.fromId)?.name} - {r.date}</div>
              </div>
              <Badge variant={STATUS_VAR[r.status]||'warn'}>{STATUS_LABEL[r.status]||r.status}</Badge>
            </div>
          </Card>
        ))}
      </>)}
      {isCoord&&alerts.length>0&&(<>
        <SLabel style={{marginTop:myPend.length>0?10:0}}>Alertas de horas - {MONTHS_CAP[CUR_MONTH]}</SLabel>
        {alerts.map(a=>(
          <Card key={a.id} style={{marginBottom:8,borderColor:a.severity==='red'?C.red+'44':C.yellow+'44'}}>
            <div style={{display:'flex',gap:9,alignItems:'center'}}>
              <Ava init={a.init} size={30}/>
              <div style={{flex:1}}><div style={{fontSize:12,fontWeight:700,color:C.text}}>{a.name}</div><div style={{fontSize:11,color:C.muted}}>{a.hours}h de {expH}h objetivo</div></div>
              <div style={{textAlign:'right'}}>
                <div style={{fontFamily:'JetBrains Mono',fontSize:13,fontWeight:700,color:a.severity==='red'?C.red:C.yellow}}>{a.dev>=0?'+':''}{a.dev}h</div>
                <Badge variant={a.severity==='red'?'red':'warn'}>{a.severity==='red'?'Critico':'Aviso'}</Badge>
              </div>
            </div>
          </Card>
        ))}
      </>)}
      {myPend.length===0&&(!isCoord||alerts.length===0)&&(
        <div style={{textAlign:'center',marginTop:56}}>
          <CheckCircle size={32} color={C.green} style={{margin:'0 auto 12px'}}/>
          <p style={{color:C.muted,fontSize:13,fontWeight:600}}>Todo en orden</p>
          <p style={{color:C.dim,fontSize:12,marginTop:4}}>Sin alertas ni solicitudes pendientes</p>
        </div>
      )}
    </div>
  );
}

// --- TEAM MANAGER -------------------------------------------------------------
function TeamManagerScreen({emps,setEmps,pins,setPins,monthSched,shifts}){
  const [sub,setSub]=useState('list');
  const [editId,setEId]=useState(null);
  const [eName,setEN]=useState('');const [eInit,setEI]=useState('');const [ePin,setEP]=useState('');const [eRole,setER]=useState('employee');
  const [showPId,setSPI]=useState(null);const [confDel,setCD]=useState(null);
  const [newName,setNN]=useState('');const [newRole,setNR]=useState('employee');const [newPin,setNP]=useState('0000');
  const [addMsg,setAM]=useState('');const [editMsg,setEM]=useState('');
  const employees=emps.filter(e=>e.role==='employee');
  const maxId=Math.max(...emps.map(e=>e.id),14);
  const startEdit=emp=>{setEId(emp.id);setEN(emp.name);setEI(emp.init);setEP(pins[emp.id]||'0000');setER(emp.role);setEM('');};
  const saveEdit=()=>{
    if(!eName.trim()){setEM('El nombre no puede estar vacio');return;}
    if(ePin&&!/^\d{4}$/.test(ePin)){setEM('El PIN debe ser exactamente 4 digitos');return;}
    const init=eInit.trim().toUpperCase().slice(0,2)||autoInit(eName);
    setEmps(p=>p.map(e=>e.id===editId?{...e,name:eName.trim(),init,role:eRole}:e));
    if(ePin)setPins(p=>({...p,[editId]:ePin}));
    setEId(null);setEM('');
  };
  const addEmp=()=>{
    if(!newName.trim()){setAM('error:Introduce un nombre');return;}
    if(!/^\d{4}$/.test(newPin)){setAM('error:El PIN debe ser 4 digitos numericos');return;}
    const id=maxId+1;const init=autoInit(newName);
    setEmps(p=>[...p.filter(e=>e.role==='employee'),{id,name:newName.trim(),init,role:newRole},...p.filter(e=>e.role==='coordinator')]);
    setPins(p=>({...p,[id]:newPin}));
    setNN('');setNP('0000');setNR('employee');
    setAM('ok:Empleado anadido correctamente');setTimeout(()=>setAM(''),3000);
  };
  const delEmp=id=>{setEmps(p=>p.filter(e=>e.id!==id));setPins(p=>{const n={...p};delete n[id];return n;});setCD(null);};
  const RolBtns=({val,set})=>(
    <div style={{display:'flex',gap:7}}>
      {['employee','coordinator'].map(r=><button key={r} onClick={()=>set(r)} style={{flex:1,padding:'8px',borderRadius:9,cursor:'pointer',fontSize:11,fontWeight:700,background:val===r?C.accentMut:C.elevated,border:`1px solid ${val===r?C.accentBrd:C.border}`,color:val===r?C.accent:C.muted}}>{r==='coordinator'?'Coordinador/a':'Empleado/a'}</button>)}
    </div>
  );
  const expH=expectedMonthHours(CUR_YEAR,CUR_MONTH);
  return(
    <div style={{padding:'0 15px'}}>
      <div style={{marginBottom:13}}>
        <h2 style={{fontSize:16,fontWeight:800,color:C.text,marginBottom:2}}>Gestion del equipo</h2>
        <p style={{fontSize:12,color:C.muted}}>{employees.length} empleados</p>
      </div>
      <div style={{display:'flex',gap:7,marginBottom:14}}>
        {[['list','Empleados'],['add','Anadir']].map(([v,l])=>(
          <button key={v} onClick={()=>setSub(v)} style={{flex:1,padding:'8px',borderRadius:10,cursor:'pointer',fontSize:12,fontWeight:700,background:sub===v?C.accentMut:C.card,border:`1px solid ${sub===v?C.accentBrd:C.border}`,color:sub===v?C.accent:C.muted}}>{l}</button>
        ))}
      </div>
      {sub==='list'&&(
        <div>
          {emps.map(emp=>{
            const isEd=editId===emp.id;const h=monthNetHours(emp.id,monthSched,shifts,CUR_YEAR,CUR_MONTH);
            const dev=Math.round((h-expH)*10)/10;const col=Math.abs(dev)<expH*0.05?C.green:Math.abs(dev)<expH*0.12?C.yellow:C.red;
            return(
              <Card key={emp.id} style={{marginBottom:8,borderColor:isEd?C.accentBrd:C.border}}>
                {isEd?(
                  <div>
                    <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
                      <div style={{display:'flex',alignItems:'center',gap:8}}><Ava init={eInit||autoInit(eName)||'?'} size={32}/><span style={{fontSize:13,fontWeight:700,color:C.accent}}>Editando</span></div>
                      <button onClick={()=>setEId(null)} style={{background:'none',border:'none',cursor:'pointer',color:C.muted}}><X size={16}/></button>
                    </div>
                    <div style={{display:'grid',gridTemplateColumns:'1fr 68px',gap:8,marginBottom:10}}>
                      <div><SLabel>Nombre</SLabel><input value={eName} onChange={e=>setEN(e.target.value)} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,padding:'9px 12px',color:C.text,fontSize:13,width:'100%',outline:'none'}}/></div>
                      <div><SLabel>Iniciales</SLabel><input value={eInit} maxLength={2} onChange={e=>setEI(e.target.value.toUpperCase().slice(0,2))} placeholder={autoInit(eName)} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,padding:'9px 8px',color:C.text,fontSize:14,width:'100%',fontFamily:'JetBrains Mono',outline:'none',textAlign:'center'}}/></div>
                    </div>
                    <div style={{marginBottom:10}}>
                      <SLabel>PIN (4 digitos)</SLabel>
                      <div style={{display:'flex',alignItems:'center',gap:9}}>
                        <input type={showPId===emp.id?'text':'password'} value={ePin} onChange={e=>setEP(e.target.value.replace(/\D/g,'').slice(0,4))} inputMode="numeric" maxLength={4} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,padding:'9px 12px',color:C.text,fontSize:20,fontFamily:'JetBrains Mono',width:110,outline:'none',letterSpacing:'0.35em',textAlign:'center'}}/>
                        <button onClick={()=>setSPI(showPId===emp.id?null:emp.id)} style={{background:'none',border:'none',cursor:'pointer',color:C.muted}}>{showPId===emp.id?<EyeOff size={16}/>:<Eye size={16}/>}</button>
                      </div>
                    </div>
                    <div style={{marginBottom:12}}><SLabel>Rol</SLabel><RolBtns val={eRole} set={setER}/></div>
                    {editMsg&&<div style={{background:C.redMut,border:`1px solid ${C.red}44`,borderRadius:8,padding:'7px 11px',marginBottom:10,fontSize:12,color:C.red}}>{editMsg}</div>}
                    <div style={{display:'flex',gap:8}}>
                      <Btn secondary small onClick={()=>setEId(null)} style={{flex:1}}>Cancelar</Btn>
                      <Btn small onClick={saveEdit} style={{flex:1}}><Save size={13} style={{marginRight:5,verticalAlign:'middle'}}/>Guardar</Btn>
                    </div>
                  </div>
                ):(
                  <div style={{display:'flex',alignItems:'center',gap:10}}>
                    <Ava init={emp.init} size={35}/>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:13,fontWeight:700,color:C.text}}>{emp.name}</div>
                      <div style={{display:'flex',gap:6,alignItems:'center',marginTop:2,flexWrap:'wrap'}}>
                        <span style={{fontSize:10,color:emp.role==='coordinator'?C.accent:C.muted,fontWeight:600}}>{emp.role==='coordinator'?'Coordinadora':'Empleado/a'}</span>
                        <span style={{fontSize:10,color:col,fontFamily:'JetBrains Mono'}}>{h}h ({dev>=0?'+':''}{dev})</span>
                      </div>
                    </div>
                    <div style={{display:'flex',gap:5,flexShrink:0}}>
                      <button onClick={()=>startEdit(emp)} style={{background:C.accentMut,border:`1px solid ${C.accentBrd}`,borderRadius:7,padding:'5px 9px',cursor:'pointer',color:C.accent}}><Edit3 size={13}/></button>
                      {emp.role!=='coordinator'&&<button onClick={()=>setCD(emp.id)} style={{background:C.redMut,border:`1px solid ${C.red}44`,borderRadius:7,padding:'5px 9px',cursor:'pointer',color:C.red}}><Trash2 size={13}/></button>}
                    </div>
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}
      {sub==='add'&&(
        <Card>
          <p style={{fontSize:13,fontWeight:700,color:C.text,marginBottom:14}}>Nuevo miembro del equipo</p>
          <div style={{marginBottom:11}}><SLabel>Nombre completo</SLabel><input value={newName} onChange={e=>setNN(e.target.value)} placeholder="Ej: Laura Garcia" style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,padding:'10px 12px',color:C.text,fontSize:13,width:'100%',outline:'none'}}/></div>
          {newName.trim()&&<div style={{background:C.elevated,borderRadius:9,padding:'9px 12px',marginBottom:11,display:'flex',alignItems:'center',gap:9}}><Ava init={autoInit(newName)} size={30}/><div><div style={{fontSize:12,fontWeight:700,color:C.text}}>{newName.trim()}</div><div style={{fontSize:10,color:C.muted}}>Iniciales: <b style={{fontFamily:'JetBrains Mono',color:C.text}}>{autoInit(newName)}</b></div></div></div>}
          <div style={{marginBottom:11}}><SLabel>PIN de acceso (4 digitos)</SLabel><input value={newPin} onChange={e=>setNP(e.target.value.replace(/\D/g,'').slice(0,4))} inputMode="numeric" maxLength={4} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,padding:'10px 14px',color:C.text,fontSize:22,fontFamily:'JetBrains Mono',outline:'none',letterSpacing:'0.35em',width:130,textAlign:'center'}}/></div>
          <div style={{marginBottom:16}}><SLabel>Rol</SLabel><RolBtns val={newRole} set={setNR}/></div>
          {addMsg&&<div style={{background:addMsg.startsWith('ok:')?C.greenMut:C.redMut,border:`1px solid ${addMsg.startsWith('ok:')?C.green:C.red}44`,borderRadius:8,padding:'8px 12px',marginBottom:12,fontSize:12,color:addMsg.startsWith('ok:')?C.green:C.red}}>{addMsg.replace(/^(ok|error):/,'')}</div>}
          <Btn onClick={addEmp} disabled={!newName.trim()||newPin.length!==4}><UserPlus size={15} style={{marginRight:8,verticalAlign:'middle'}}/>Anadir al equipo</Btn>
        </Card>
      )}
      {confDel!==null&&(
        <div style={{position:'absolute',top:0,left:0,right:0,bottom:0,background:'rgba(10,14,20,0.92)',zIndex:300,display:'flex',alignItems:'center',justifyContent:'center',padding:24}}>
          <Card style={{width:'100%',maxWidth:340,animation:'slideUp 0.2s ease'}}>
            <div style={{textAlign:'center',marginBottom:18}}>
              <div style={{width:46,height:46,borderRadius:13,background:C.redMut,display:'flex',alignItems:'center',justifyContent:'center',margin:'0 auto 13px'}}><Trash2 size={21} color={C.red}/></div>
              <p style={{fontSize:14,fontWeight:700,color:C.text,marginBottom:7}}>Eliminar empleado</p>
              <p style={{fontSize:12,color:C.muted,lineHeight:1.5}}>Eliminar a <b style={{color:C.text}}>{emps.find(e=>e.id===confDel)?.name}</b>? Esta accion no se puede deshacer.</p>
            </div>
            <div style={{display:'flex',gap:8}}>
              <Btn secondary small onClick={()=>setCD(null)} style={{flex:1}}>Cancelar</Btn>
              <Btn danger small onClick={()=>delEmp(confDel)} style={{flex:1}}>Eliminar</Btn>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

// --- PROFILE ------------------------------------------------------------------
function ProfileScreen({user,pins,setPins,monthSched,shifts,onLogout}){
  const [sub,setSub]=useState('info');
  const [cur,setCur]=useState('');const [p1,setP1]=useState('');const [p2,setP2]=useState('');
  const [msg,setMsg]=useState({t:'',ok:false});
  const [sc,setSC]=useState(false);const [sn,setSN]=useState(false);
  const netH=monthNetHours(user.id,monthSched,shifts,CUR_YEAR,CUR_MONTH);
  const expH=expectedMonthHours(CUR_YEAR,CUR_MONTH);
  const diff=Math.round((netH-expH)*10)/10;
  const diffCol=Math.abs(diff)<expH*0.05?C.green:Math.abs(diff)<expH*0.12?C.yellow:C.red;
  const todayDate=today();
  const empData=monthSched[user.id]||{};
  const workDays=Object.values(empData).filter(Boolean).length;

  const changePin=()=>{
    if(cur!==pins[user.id]){setMsg({t:'PIN actual incorrecto',ok:false});return;}
    if(!/^\d{4}$/.test(p1)){setMsg({t:'El nuevo PIN debe tener 4 digitos',ok:false});return;}
    if(p1!==p2){setMsg({t:'Los PINs nuevos no coinciden',ok:false});return;}
    setPins(p=>({...p,[user.id]:p1}));setMsg({t:'PIN cambiado correctamente',ok:true});
    setCur('');setP1('');setP2('');setTimeout(()=>setMsg({t:'',ok:false}),3000);
  };
  const PR=({label,val,set,show,setShow})=>(
    <div style={{marginBottom:11}}>
      <SLabel>{label}</SLabel>
      <div style={{display:'flex',alignItems:'center',gap:9}}>
        <input type={show?'text':'password'} value={val} onChange={e=>set(e.target.value.replace(/\D/g,'').slice(0,4))} inputMode="numeric" maxLength={4} placeholder="****" style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,padding:'10px 14px',color:C.text,fontSize:22,fontFamily:'JetBrains Mono',outline:'none',letterSpacing:'0.4em',width:120,textAlign:'center'}}/>
        {setShow&&<button onClick={()=>setShow(s=>!s)} style={{background:'none',border:'none',cursor:'pointer',color:C.muted}}>{show?<EyeOff size={16}/>:<Eye size={16}/>}</button>}
      </div>
    </div>
  );

  return(
    <div style={{padding:'0 15px'}}>
      <div style={{display:'flex',alignItems:'center',gap:13,marginBottom:16}}>
        <Ava init={user.init} size={54}/>
        <div style={{flex:1}}>
          <h2 style={{fontSize:17,fontWeight:800,color:C.text}}>{user.name}</h2>
          <p style={{fontSize:11,color:user.role==='coordinator'?C.accent:C.muted,marginTop:2,fontWeight:600}}>{user.role==='coordinator'?'Coordinadora':'Empleado/a'}</p>
        </div>
        <button onClick={onLogout} style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,padding:'7px 11px',cursor:'pointer',display:'flex',alignItems:'center',gap:5,color:C.muted,fontSize:11}}><LogOut size={13}/> Salir</button>
      </div>
      <div style={{display:'flex',gap:7,marginBottom:14}}>
        {[['info','Mi mes'],['pin','Cambiar PIN']].map(([v,l])=>(
          <button key={v} onClick={()=>setSub(v)} style={{flex:1,padding:'8px',borderRadius:10,cursor:'pointer',fontSize:12,fontWeight:700,background:sub===v?C.accentMut:C.card,border:`1px solid ${sub===v?C.accentBrd:C.border}`,color:sub===v?C.accent:C.muted}}>{l}</button>
        ))}
      </div>

      {sub==='info'&&(<>
        <div style={{background:C.accentMut,border:`1px solid ${C.accentBrd}`,borderRadius:10,padding:'8px 13px',marginBottom:13,textAlign:'center'}}>
          <span style={{color:C.accent,fontSize:12,fontWeight:700}}>
            Hoy: {DAYSL[(todayDate.getDay()+6)%7]} {todayDate.getDate()} de {MONTHS[todayDate.getMonth()]} de {todayDate.getFullYear()}
          </span>
        </div>
        <GoalBanner netH={netH} expectedH={expH} style={{marginBottom:13}}/>

        <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8,marginBottom:14}}>
          {[[netH+'h',C.blue,'Horas netas'],[(diff>=0?'+':'')+diff+'h',diffCol,'Saldo mes'],[workDays+'d',C.purple,'Dias trabajo']].map(([v,col,l])=>(
            <Card key={l} style={{textAlign:'center',padding:'11px 6px'}}>
              <div style={{fontFamily:'JetBrains Mono',fontSize:16,fontWeight:700,color:col}}>{v}</div>
              <div style={{fontSize:9,color:C.muted,marginTop:2}}>{l}</div>
            </Card>
          ))}
        </div>

        <SLabel>Mi mes - {MONTHS_CAP[CUR_MONTH]} {CUR_YEAR}</SLabel>
        <MonthCalView empId={user.id} monthSched={monthSched} shifts={shifts} year={CUR_YEAR} month={CUR_MONTH}/>

        <div style={{marginTop:13}}>
          <SLabel>Desglose semanal</SLabel>
          {Array.from({length:Math.ceil(daysInMonth(CUR_YEAR,CUR_MONTH)/7)},(_,wi)=>{
            let wh=0;const days=[];
            for(let d=wi*7+1;d<=Math.min(wi*7+7,daysInMonth(CUR_YEAR,CUR_MONTH));d++){
              const key=getDayKey(CUR_YEAR,CUR_MONTH,d);
              const sid=empData[key];
              if(sid&&shifts[sid])wh+=shifts[sid].netHours;
              days.push({d,sid});
            }
            const wd=Math.round((wh-40)*10)/10;
            const col=Math.abs(wd)<2?C.green:Math.abs(wd)<5?C.yellow:C.red;
            return(
              <div key={wi} style={{display:'flex',alignItems:'center',gap:8,marginBottom:7,padding:'8px 11px',background:C.elevated,borderRadius:10}}>
                <span style={{fontSize:10,color:C.muted,width:56,flexShrink:0}}>Semana {wi+1}</span>
                <div style={{flex:1,height:4,background:C.dim,borderRadius:2}}>
                  <div style={{height:4,borderRadius:2,background:col,width:`${Math.min(100,(wh/40)*100)}%`}}/>
                </div>
                <span style={{fontFamily:'JetBrains Mono',fontSize:11,fontWeight:700,color:C.text,minWidth:28}}>{wh}h</span>
                <span style={{fontFamily:'JetBrains Mono',fontSize:10,color:col,minWidth:32}}>{wd>=0?'+':''}{wd}h</span>
              </div>
            );
          })}
        </div>
        <div style={{marginTop:8,padding:'8px 12px',background:C.elevated,borderRadius:9}}>
          <p style={{fontSize:10,color:C.muted,lineHeight:1.6}}>
            <b style={{color:C.text}}>Calculo de horas:</b> referencia 40h netas/sem.<br/>
            Turno A: 6h - Turno B: 7h (30min desc.) - Turno C: 10h (1h desc.)
          </p>
        </div>
      </>)}

      {sub==='pin'&&(
        <Card>
          <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:18}}>
            <div style={{width:38,height:38,borderRadius:10,background:C.accentMut,display:'flex',alignItems:'center',justifyContent:'center'}}><Key size={18} color={C.accent}/></div>
            <div><div style={{fontSize:13,fontWeight:700,color:C.text}}>Cambiar PIN de acceso</div><div style={{fontSize:11,color:C.muted}}>Tu PIN personal de 4 digitos</div></div>
          </div>
          <PR label="PIN actual" val={cur} set={setCur} show={sc} setShow={setSC}/>
          <PR label="Nuevo PIN" val={p1} set={setP1} show={sn} setShow={setSN}/>
          <PR label="Confirmar nuevo PIN" val={p2} set={setP2} show={false} setShow={null}/>
          {msg.t&&<div style={{background:msg.ok?C.greenMut:C.redMut,border:`1px solid ${msg.ok?C.green:C.red}44`,borderRadius:8,padding:'8px 12px',marginBottom:14,fontSize:12,color:msg.ok?C.green:C.red}}>{msg.t}</div>}
          <Btn onClick={changePin} disabled={!cur||!p1||!p2}><Lock size={14} style={{marginRight:8,verticalAlign:'middle'}}/>Cambiar PIN</Btn>
        </Card>
      )}
    </div>
  );
}

// --- EVENT MODAL --------------------------------------------------------------
function EventModal({user, emps, defaultDate, onClose, onSubmit}){
  const [step, setStep] = useState(1);
  const [type, setType] = useState(null);
  const [title, setTitle] = useState('');
  const [dateKey, setDateKey] = useState(defaultDate||'');
  const [duration, setDuration] = useState(30);
  const [visibility, setVisibility] = useState('self');
  const [note, setNote] = useState('');

  const et = EVENT_TYPES.find(t=>t.id===type);

  const canNext = () => {
    if(step===1) return !!type;
    if(step===2) return !!dateKey;
    return true;
  };

  const submit = () => {
    onSubmit({
      id: Date.now(),
      type,
      title: title.trim() || (et?.label||'Aviso'),
      dateKey,
      duration: et?.hasDuration ? duration : 0,
      visibility,
      note: note.trim(),
      ownerId: user.id,
      createdAt: new Date().toISOString().slice(0,10),
    });
  };

  return(
    <div style={{position:'absolute',top:0,left:0,right:0,bottom:0,background:C.bg,display:'flex',flexDirection:'column',zIndex:200,animation:'slideUp 0.22s ease'}}>
      <div style={{padding:'13px 17px',display:'flex',alignItems:'center',gap:11,borderBottom:`1px solid ${C.border}`,flexShrink:0}}>
        <button onClick={step===1?onClose:()=>setStep(s=>s-1)} style={{background:'none',border:'none',cursor:'pointer',color:C.muted,padding:3}}><ChevronLeft size={21}/></button>
        <div style={{flex:1}}>
          <h2 style={{fontSize:15,fontWeight:800,color:C.text}}>Nuevo aviso personal</h2>
          <p style={{fontSize:10,color:C.muted}}>Paso {step} de 3</p>
        </div>
        <div style={{display:'flex',gap:4}}>{[1,2,3].map(s=><div key={s} style={{width:18,height:3,borderRadius:2,background:step>=s?C.purple:C.border,transition:'background 0.2s'}}/>)}</div>
      </div>

      <div style={{flex:1,overflowY:'auto',padding:'17px'}}>

        {step===1&&(
          <div style={{animation:'slideUp 0.2s ease'}}>
            <p style={{color:C.muted,fontSize:13,marginBottom:14}}>Que tipo de aviso quieres anadir?</p>
            <div style={{display:'grid',gridTemplateColumns:'repeat(2,1fr)',gap:8}}>
              {EVENT_TYPES.map(t=>(
                <button key={t.id} onClick={()=>{setType(t.id);setStep(2);}} style={{
                  background:type===t.id?`${t.color}18`:C.card,
                  border:`1.5px solid ${type===t.id?t.color+'60':C.border}`,
                  borderRadius:13,padding:'14px 10px',textAlign:'center',cursor:'pointer',
                  transition:'all 0.15s',
                }}>
                  <div style={{fontSize:26,marginBottom:7}}>{t.icon}</div>
                  <div style={{fontSize:12,fontWeight:700,color:type===t.id?t.color:C.text}}>{t.label}</div>
                  {t.hasDuration&&<div style={{fontSize:9,color:C.muted,marginTop:3}}>con duracion</div>}
                </button>
              ))}
            </div>
          </div>
        )}

        {step===2&&et&&(
          <div style={{animation:'slideUp 0.2s ease'}}>
            <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:16,background:`${et.color}15`,border:`1px solid ${et.color}33`,borderRadius:11,padding:'10px 13px'}}>
              <span style={{fontSize:24}}>{et.icon}</span>
              <div>
                <div style={{fontSize:13,fontWeight:700,color:et.color}}>{et.label}</div>
                {et.hasDuration&&<div style={{fontSize:10,color:C.muted}}>Incluye duracion aproximada</div>}
              </div>
            </div>

            <div style={{marginBottom:13}}>
              <SLabel>Titulo (opcional)</SLabel>
              <input
                value={title}
                onChange={e=>setTitle(e.target.value)}
                placeholder={et.label}
                style={{background:C.elevated,border:`1px solid ${C.border}`,borderRadius:9,padding:'10px 12px',color:C.text,fontSize:13,width:'100%',outline:'none',fontFamily:'Sora'}}
              />
            </div>

            <div style={{marginBottom:13}}>
              <SLabel>Fecha</SLabel>
              <input
                type="date"
                value={dateKey}
                onChange={e=>setDateKey(e.target.value)}
                style={{background:C.elevated,border:`1px solid ${dateKey?C.accentBrd:C.border}`,borderRadius:9,padding:'10px 12px',color:C.text,fontSize:13,width:'100%',outline:'none',fontFamily:'JetBrains Mono',colorScheme:'dark'}}
              />
            </div>

            {et.hasDuration&&(
              <div style={{marginBottom:13}}>
                <SLabel>Duracion aproximada: <span style={{fontFamily:'JetBrains Mono',color:C.accent}}>{duration} min</span></SLabel>
                <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
                  {[15,30,45,60,90,120].map(m=>(
                    <button key={m} onClick={()=>setDuration(m)} style={{
                      padding:'7px 12px',borderRadius:8,fontSize:11,fontWeight:700,cursor:'pointer',
                      background:duration===m?C.accentMut:C.elevated,
                      border:`1px solid ${duration===m?C.accentBrd:C.border}`,
                      color:duration===m?C.accent:C.muted,
                    }}>{m<60?`${m}min`:`${m/60}h`}</button>
                  ))}
                </div>
              </div>
            )}

            <div style={{marginBottom:13}}>
              <SLabel>Quien puede verlo?</SLabel>
              <div style={{display:'flex',flexDirection:'column',gap:6}}>
                {VISIBILITY_OPTS.map(v=>(
                  <button key={v.id} onClick={()=>setVisibility(v.id)} style={{
                    display:'flex',alignItems:'center',gap:11,
                    background:visibility===v.id?`${C.purple}18`:C.card,
                    border:`1.5px solid ${visibility===v.id?C.purple+'55':C.border}`,
                    borderRadius:11,padding:'11px 13px',cursor:'pointer',textAlign:'left',
                  }}>
                    <span style={{fontSize:18,flexShrink:0}}>{v.icon}</span>
                    <div style={{flex:1}}>
                      <div style={{fontSize:13,fontWeight:700,color:visibility===v.id?C.purple:C.text}}>{v.label}</div>
                      <div style={{fontSize:10,color:C.muted}}>{v.desc}</div>
                    </div>
                    {visibility===v.id&&<Check size={14} color={C.purple}/>}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {step===3&&et&&(
          <div style={{animation:'slideUp 0.2s ease'}}>
            <SLabel>Nota adicional (opcional)</SLabel>
            <textarea
              value={note} onChange={e=>setNote(e.target.value)}
              placeholder="Informacion extra, recordatorio, etc..."
              style={{background:C.card,border:`1px solid ${C.border}`,borderRadius:11,color:C.text,fontFamily:'Sora',fontSize:13,padding:'12px',width:'100%',height:80,marginBottom:16}}
            />
            <Card style={{marginBottom:14,border:`1px solid ${et.color}33`}}>
              <p style={{fontSize:11,color:C.muted,marginBottom:10,fontWeight:700}}>Resumen del aviso</p>
              <div style={{display:'flex',gap:11,alignItems:'flex-start'}}>
                <span style={{fontSize:28}}>{et.icon}</span>
                <div style={{flex:1}}>
                  <div style={{fontSize:14,fontWeight:700,color:C.text,marginBottom:4}}>{title||et.label}</div>
                  <div style={{fontSize:12,color:et.color,marginBottom:5,fontWeight:600}}>{et.label}</div>
                  <div style={{fontSize:11,color:C.muted,marginBottom:3}}>
                    <span style={{fontFamily:'JetBrains Mono'}}>{dateKey?dateStrToLabel(dateKey):'--'}</span>
                  </div>
                  {et.hasDuration&&<div style={{fontSize:11,color:C.muted,display:'flex',alignItems:'center',gap:4}}><Clock size={10}/>{duration} min aprox.</div>}
                  <div style={{marginTop:6,display:'flex',alignItems:'center',gap:5}}>
                    {(()=>{const vis=VISIBILITY_OPTS.find(v=>v.id===visibility);return vis?<><span style={{fontSize:13}}>{vis.icon}</span><span style={{fontSize:10,color:C.muted}}>{vis.label}</span></>:null;})()}
                  </div>
                  {note.trim()&&<p style={{fontSize:10,color:C.muted,marginTop:5,fontStyle:'italic'}}>"{note.trim()}"</p>}
                </div>
              </div>
            </Card>
          </div>
        )}
      </div>

      <div style={{padding:'12px 17px',borderTop:`1px solid ${C.border}`,flexShrink:0}}>
        {step<3
          ?<Btn onClick={()=>setStep(s=>s+1)} disabled={!canNext()} style={{background:canNext()?C.purple:''}}>Continuar</Btn>
          :<Btn onClick={submit} style={{background:C.purple}}>Guardar aviso</Btn>
        }
      </div>
    </div>
  );
}

// --- APP ----------------------------------------------------------------------
export default function App(){
  const [user,setUser]         = useState(null);
  const [tab,setTab]           = useState('calendar');
  const [emps,setEmps]         = useState(INIT_EMPS);
  const [pins,setPins]         = useState(INIT_PINS);
  const [monthSched,setMSched] = useState(INIT_MONTH_SCHED);
  const [shifts,setShifts]     = useState(SHIFTS_DEFAULT);
  const [requests,setReqs]     = useState(INIT_REQS);
  const [history,setHist]      = useState(INIT_HIST);
  const [showModal,setMod]     = useState(false);
  const [events,setEvents]     = useState([]);
  const isCoord=user?.role==='coordinator';

  const pendingCount=useMemo(()=>{
    if(!user)return 0;
    if(isCoord)return requests.filter(r=>r.status==='pending_coordinator').length;
    return requests.filter(r=>(r.fromId===user.id||r.toId===user.id)&&r.status.includes('pending')).length;
  },[user,requests,isCoord]);

  const addReq=req=>setReqs(r=>[...r,{...req,id:Date.now()}]);

  const approveReq=id=>{
    const r=requests.find(x=>x.id===id);
    if(!r)return;
    if(r.type==='swap'&&r.fromDate&&r.toDate){
      setMSched(s=>{
        const ns=JSON.parse(JSON.stringify(s));
        if(!ns[r.fromId])ns[r.fromId]={};
        if(!ns[r.toId])ns[r.toId]={};
        const fSid=ns[r.fromId][r.fromDate];
        const tSid=ns[r.toId][r.toDate];
        ns[r.fromId][r.fromDate]=tSid||null;
        ns[r.toId][r.toDate]=fSid||null;
        return ns;
      });
    } else if(r.type==='self_swap'&&r.fromDate&&r.toDate){
      setMSched(s=>{
        const ns=JSON.parse(JSON.stringify(s));
        if(!ns[r.fromId])ns[r.fromId]={};
        const sid=ns[r.fromId][r.fromDate];
        ns[r.fromId][r.toDate]=sid||null;
        ns[r.fromId][r.fromDate]=null;
        return ns;
      });
    }
    setHist(h=>[...h,{id:Date.now(),type:r.type,desc:'Cambio aprobado',fromId:r.fromId,toId:r.toId||null,date:new Date().toISOString().slice(0,10),status:'applied'}]);
    setReqs(rs=>rs.filter(x=>x.id!==id));
  };

  const rejectReq=id=>{
    const r=requests.find(x=>x.id===id);
    if(r)setHist(h=>[...h,{id:Date.now(),type:r.type,desc:'Solicitud rechazada',fromId:r.fromId,toId:r.toId||null,date:new Date().toISOString().slice(0,10),status:'rejected'}]);
    setReqs(rs=>rs.filter(x=>x.id!==id));
  };

  const acceptSwap=id=>setReqs(rs=>rs.map(r=>r.id===id?{...r,status:'pending_coordinator'}:r));
  const claimMkt=(rid,cid,claimerShift)=>setReqs(rs=>rs.map(r=>r.id===rid?{...r,toId:cid,claimerShift:claimerShift||null,status:'pending_coordinator'}:r));

  const curUser=useMemo(()=>user?emps.find(e=>e.id===user.id)||user:null,[user,emps]);
  const TITLES={calendar:isCoord?'Calendario equipo':'Mi mes',requests:'Solicitudes',market:'Mercado de turnos',metrics:'Metricas del equipo',schedule:'Cuadrante',notifs:'Alertas',team:'Gestion del equipo',profile:'Mi perfil'};

  if(!curUser)return(
    <div style={{background:C.bg,minHeight:'100vh',maxWidth:420,margin:'0 auto',fontFamily:'Sora,sans-serif',color:C.text,overflowY:'auto'}}>
      <style>{FONT_CSS}</style>
      <LoginScreen emps={emps} pins={pins} onLogin={setUser}/>
    </div>
  );

  return(
    <div style={{background:C.bg,height:'100vh',maxWidth:420,margin:'0 auto',fontFamily:'Sora,sans-serif',color:C.text,display:'flex',flexDirection:'column',position:'relative',overflow:'hidden'}}>
      <style>{FONT_CSS}</style>
      <div style={{padding:'11px 16px 9px',borderBottom:`1px solid ${C.border}`,flexShrink:0}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <div style={{display:'flex',alignItems:'center',gap:9}}>
            <div style={{width:28,height:28,borderRadius:8,background:C.accentMut,border:`1px solid ${C.accentBrd}`,display:'flex',alignItems:'center',justifyContent:'center'}}><Calendar size={14} color={C.accent}/></div>
            <div>
              <div style={{fontSize:13,fontWeight:700,color:C.text}}>{TITLES[tab]||'TurnoApp'}</div>
              <div style={{fontSize:10,color:C.muted}}>{MONTHS_CAP[CUR_MONTH]} {CUR_YEAR}</div>
            </div>
          </div>
          <div style={{display:'flex',gap:7,alignItems:'center'}}>
            {!isCoord&&['calendar','market'].includes(tab)&&(
              <button onClick={()=>setMod(true)} style={{background:C.accentMut,border:`1px solid ${C.accentBrd}`,borderRadius:9,padding:'6px 11px',cursor:'pointer',display:'flex',alignItems:'center',gap:5}}>
                <Plus size={13} color={C.accent}/><span style={{fontSize:11,fontWeight:700,color:C.accent}}>Solicitar</span>
              </button>
            )}
            <button onClick={()=>setUser(null)} style={{background:'none',border:'none',cursor:'pointer',color:C.muted,padding:2}}><LogOut size={16}/></button>
          </div>
        </div>
      </div>
      <div style={{flex:1,overflowY:'auto',paddingTop:14,paddingBottom:8}}>
        {tab==='calendar'&&<CalendarScreen user={curUser} emps={emps} monthSched={monthSched} shifts={shifts} requests={requests} events={events} onAddEvent={ev=>setEvents(es=>[...es,ev])} onDeleteEvent={id=>setEvents(es=>es.filter(e=>e.id!==id))}/>}
        {tab==='requests'&&<RequestsScreen user={curUser} emps={emps} requests={requests} history={history} shifts={shifts} onApprove={approveReq} onReject={rejectReq} onAcceptSwap={acceptSwap}/>}
        {tab==='market'  &&<MarketScreen   user={curUser} emps={emps} requests={requests} shifts={shifts} monthSched={monthSched} onClaim={claimMkt}/>}
        {tab==='metrics' &&<MetricsScreen  emps={emps} monthSched={monthSched} shifts={shifts} requests={requests} history={history}/>}
        {tab==='schedule'&&<ScheduleEditor emps={emps} monthSched={monthSched} shifts={shifts} onUpdateMonthSched={setMSched} onUpdateShifts={setShifts}/>}
        {tab==='notifs'  &&<NotifsScreen   user={curUser} emps={emps} requests={requests} monthSched={monthSched} shifts={shifts}/>}
        {tab==='team'    &&<TeamManagerScreen emps={emps} setEmps={setEmps} pins={pins} setPins={setPins} monthSched={monthSched} shifts={shifts}/>}
        {tab==='profile' &&<ProfileScreen  user={curUser} pins={pins} setPins={setPins} monthSched={monthSched} shifts={shifts} onLogout={()=>setUser(null)}/>}
      </div>
      <BottomNav tab={tab} setTab={setTab} user={curUser} pendingCount={pendingCount}/>
      {showModal&&<RequestModal user={curUser} emps={emps} monthSched={monthSched} shifts={shifts} onClose={()=>setMod(false)} onSubmit={req=>{addReq(req);setMod(false);}}/>}
    </div>
  );
}
